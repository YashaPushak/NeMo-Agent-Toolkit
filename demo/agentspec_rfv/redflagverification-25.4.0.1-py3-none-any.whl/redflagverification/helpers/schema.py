# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

import json
from typing import Any, cast


def format_schema_str(schema_json: dict[str, Any]) -> str:
    """
    Returns a formatted string with tables, their descriptions, and columns (with descriptions)
    from a schema definition JSON/dict.
    """
    lines = []
    for table in schema_json.get("tables", []):
        lines.append(f"{table['name']}**{table['description']}")
        lines.append(f"Columns :")
        for column in table.get("columns", []):
            lines.append(f"{column['name']}**{column['description']}")
        lines.append("")  # Blank line, prettier.

    return "\n".join(lines)


def load_schema_json(schema_path: str) -> dict[str, Any]:
    """
    Loads and parses a JSON schema from the specified file path.

    Args:
        schema_path: Path to the JSON schema file.

    Returns:
        The parsed schema as a dictionary.

    Raises:
        ValueError: If the file path is empty or the JSON is invalid.
        FileNotFoundError: If the file does not exist.
    """
    if not schema_path:
        raise ValueError("'schema_path' is not set or is empty.")
    try:
        with open(schema_path, "r", encoding="utf-8") as f:
            schema_json = json.load(f)
            return cast(dict[str, Any], schema_json)
    except FileNotFoundError:
        raise FileNotFoundError(f"Schema file not found: {schema_path}")
    except json.JSONDecodeError as ex:
        raise ValueError(f"Error decoding JSON in file '{schema_path}': {ex}")
