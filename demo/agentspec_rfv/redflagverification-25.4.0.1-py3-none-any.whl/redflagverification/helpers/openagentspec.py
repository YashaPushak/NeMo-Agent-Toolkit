# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

import re
from textwrap import dedent
from typing import Any, List, Optional, Union

from wayflowcore.outputparser import RegexPattern
from wayflowcore.property import BooleanProperty, ListProperty, StringProperty
from wayflowcore.steps import (
    RegexExtractionStep,
    TemplateRenderingStep,
    ToolExecutionStep,
)
from wayflowcore.tools import ServerTool


def regex_extraction(
    text: str, regex_pattern: str, return_first_match_only: bool
) -> Union[str, List[str]]:
    regex_pattern_ = RegexPattern.from_str(regex_pattern, flags=None)
    matches: list[str] = re.findall(
        pattern=regex_pattern_.pattern, string=text, flags=regex_pattern_.flags or 0
    )
    matches = [m for m in matches if m != ""]
    return_first = regex_pattern_.match == "first"
    if len(matches) == 0:
        if return_first_match_only:
            return ""
        else:
            return []
    else:
        if return_first_match_only:
            return matches[0] if return_first else matches[-1]
        else:
            return matches


def get_regex_extraction_step(
    regex_pattern: str,
    return_first_match_only: bool = True,
    name: Optional[str] = None,
    output_name: str = RegexExtractionStep.OUTPUT,
) -> ToolExecutionStep:
    return ToolExecutionStep(
        name=name,
        tool=ServerTool(
            name="regex_extraction",
            description="Regex extraction",
            func=regex_extraction,
            input_descriptors=[
                StringProperty(name=RegexExtractionStep.TEXT),
                StringProperty(name="regex_pattern", default_value=regex_pattern),
                BooleanProperty(
                    name="return_first_match_only", default_value=return_first_match_only
                ),
            ],
            output_descriptors=(
                [
                    StringProperty(name=output_name, default_value=""),
                ]
                if return_first_match_only
                else [
                    ListProperty(name=output_name, default_value=[], item_type=StringProperty()),
                ]
            ),
        ),
    )


def template_render(template: str, **kwargs: Any) -> str:
    return TemplateRenderingStep.format_template(template=template, inputs=kwargs)


def get_template_rendering_step(
    template: str,
    name: Optional[str] = None,
    output_name: str = TemplateRenderingStep.OUTPUT,
) -> ToolExecutionStep:
    return ToolExecutionStep(
        name=name,
        tool=ServerTool(
            name="template_render",
            description="Template render",
            func=template_render,
            input_descriptors=[
                StringProperty(name="template", default_value=template),
            ]
            + TemplateRenderingStep._compute_step_specific_input_descriptors_from_static_config(
                template=template
            ),
            output_descriptors=[StringProperty(name=output_name)],
        ),
    )


def render_previous_step_queries(step_value_extraction_io: str, retrieve_context_io: str) -> str:
    if step_value_extraction_io == "1":
        return ""

    previous_step_queries_prompt = dedent(
        f"""\
    Here are previous steps' sql queries to understand well what was done in previous steps to be able \
    to use them in the right way, you can directly use them since they will be available in the database:
    Query context:
    {retrieve_context_io}
    """
    )

    return previous_step_queries_prompt


def render_extra_requirements(step_value_extraction_io: str) -> str:
    extra_requirements = dedent(
        """\
    - Do NOT include the prior query context; it will be handled automatically.
    - Do NOT use any WITH clause, as one has been used already.
    """
    )

    return extra_requirements if step_value_extraction_io != "1" else ""
