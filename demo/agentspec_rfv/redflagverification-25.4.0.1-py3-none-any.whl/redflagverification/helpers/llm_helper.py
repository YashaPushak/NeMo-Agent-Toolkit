# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

import os
from typing import Optional

from wayflowcore.agent import Agent
from wayflowcore.messagelist import Message
from wayflowcore.models import OCIGenAIModel
from wayflowcore.models.llmgenerationconfig import LlmGenerationConfig
from wayflowcore.models.llmmodel import LlmModel
from wayflowcore.models.ociclientconfig import OCIClientConfigWithApiKey

SERVICE_ENDPOINT = "https://inference.generativeai.us-chicago-1.oci.oraclecloud.com"


async def get_agent_output(
    prompt: str, compartment_id: Optional[str] = None, ocigenai_model: str = "openai.o3"
) -> tuple[Optional[str], int, int]:
    llm = get_llm(compartment_id=compartment_id, ocigenai_model=ocigenai_model)
    agent = Agent(llm=llm)
    conversation = agent.start_conversation()
    conversation.append_user_message(prompt)
    await conversation.execute_async()
    last_message = conversation.get_last_message()
    if isinstance(last_message, Message):
        return (
            last_message.content,
            conversation.token_usage.input_tokens,
            conversation.token_usage.output_tokens,
        )
    else:
        return (
            None,
            conversation.token_usage.input_tokens,
            conversation.token_usage.output_tokens,
        )


def get_llm(ocigenai_model: str = "openai.o3", compartment_id: Optional[str] = None) -> LlmModel:
    generation_config = LlmGenerationConfig()
    if not compartment_id:
        compartment_id = os.getenv("OCI_COMPARTMENT_ID")
    if isinstance(compartment_id, str):
        llm = OCIGenAIModel(
            model_id=ocigenai_model,
            compartment_id=compartment_id,
            client_config=OCIClientConfigWithApiKey(
                service_endpoint=SERVICE_ENDPOINT,
            ),
            generation_config=generation_config,
        )
    else:
        raise TypeError("No Valid Compartment ID found")
    return llm
