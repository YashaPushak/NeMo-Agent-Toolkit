# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

import json
import logging
import os
import random
import time
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from types import TracebackType
from typing import Any, Optional, Type, cast

import oracledb
import requests
from requests.auth import HTTPBasicAuth
from typing_extensions import Literal

from redflagverification.configclasses import RedFlagVerificationConfig

logger = logging.getLogger(__name__)


class OracleDatabaseClient:
    """
    Provides connection and authentication to an Oracle Autonomous Database (ADW).
    Configuration is sourced from environment variables or constructor arguments.
    """

    def __init__(
        self,
        use_thick_mode: Optional[bool] = None,
    ) -> None:
        """
        Initialize Oracle DB client. Configuration for thick mode is set here.

        Args:
            use_thick_mode (bool, optional): Whether to use thick mode Oracle client.

        Returns:
            None
        """
        thick_mode_value = os.getenv("USE_THICK_MODE") if use_thick_mode is None else use_thick_mode
        if thick_mode_value is None:
            self.use_thick_mode = True  # default
        elif isinstance(thick_mode_value, bool):
            self.use_thick_mode = thick_mode_value
        else:
            self.use_thick_mode = str(thick_mode_value).strip().lower() in {"true", "1", "yes", "y"}

        self._connection: Optional[oracledb.Connection] = None
        self.is_connected = False

    def connect(
        self,
        username: Optional[str] = None,
        password: Optional[str] = None,
        dsn: Optional[str] = None,
    ) -> None:
        """
        Open the database connection using the provided credentials or the current environment configuration.

        Args:
            username (Optional[str]): Database username.
            password (Optional[str]): Database password.
            dsn (Optional[str]): Database DSN/connection string.

        Returns:
            None
        """
        username = username or os.getenv("AIACS_ADW_DB_USER_NAME")
        password = password or os.getenv("AIACS_ADW_DB_PASSWORD")
        dsn = dsn or os.getenv("AIACS_ADW_DB_CONNECTION_STRING")

        create_ssl = True
        if self.use_thick_mode:
            try:
                oracledb.init_oracle_client()
                logger.info("Oracle client initialized in thick mode")
                create_ssl = False
            except Exception as e:
                logger.warning(
                    "Failed to initialize Oracle client: %s. Falling back to thin mode.", e
                )
        logger.info("Attempting to connect to database ...")

        try:
            if create_ssl:
                import ssl

                import certifi

                ssl_context = ssl.create_default_context(cafile=certifi.where())
                logger.info("Created ssl_context")
                self._connection = oracledb.connect(
                    user=username,
                    password=password,
                    dsn=dsn,
                    ssl_context=ssl_context,
                )
            else:
                self._connection = oracledb.connect(user=username, password=password, dsn=dsn)
            self.is_connected = True
            logger.info("Successfully connected to Oracle Database")
        except Exception as e:
            self._connection = None
            self.is_connected = False
            logger.exception("Error while connecting to Oracle Database: %s", e)
            raise ConnectionError(f"Error while connecting to Oracle Database: {e}") from e

    def close(self) -> None:
        """
        Safely close any open Oracle DB connection.

        Returns:
            None
        """
        if self._connection:
            try:
                self._connection.close()
                logger.debug("Oracle DB connection closed")
            except Exception as e:
                logger.warning("Error while closing DB connection close: %s", e)
            self._connection = None
        self.is_connected = False

    @property
    def connection(self) -> Optional[oracledb.Connection]:
        """
        Get the active Oracle DB connection (may be None).

        Returns:
            Optional[oracledb.Connection]: The current DB connection or None.
        """
        return self._connection

    def __enter__(self) -> "OracleDatabaseClient":
        """
        Enter the runtime context related to this object.
        Opens the connection automatically if not already connected.
        """
        if not self.is_connected:
            self.connect()
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> Literal[False]:
        """
        Exit the runtime context and close the connection.
        Ensures resources are cleaned up even if an exception occurs.
        Because of return False, any Exception propagates.
        """
        self.close()
        if exc_type:
            logger.debug("OracleDatabaseClient context exited due to exception: %s", exc_value)
        return False

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(use_thick_mode={self.use_thick_mode}, "
            f"is_connected={self.is_connected})"
        )


class ObjectStoreClient:
    """
    Provides access to an Oracle Object Store using Pre-Authorized Requests (PARs) and handles associated credentials.
    Credentials can be fetched from a connected Oracle database.
    """

    def __init__(
        self,
        tenant_id: Optional[str] = None,
        domain_name: Optional[str] = None,
        bucket_name: Optional[str] = None,
        connect_timeout: float = 3,
        read_timeout: float = 60,
    ) -> None:
        """
        Create an ObjectStoreClient with config from environment or arguments.

        Args:
            tenant_id (Optional[str]): Oracle tenant ID.
            domain_name (Optional[str]): Object Store domain name.
            bucket_name (Optional[str]): Bucket name.
            connect_timeout (float): Timeout for get request connection.
            read_timeout (float): Timeout for get request reading.

        Returns:
            None
        """
        self.tenant_id = os.getenv("AIACS_DIS_REGULAR_TENANT_ID") or tenant_id
        self.domain_name = os.getenv("AIACS_DOMAIN_NAME") or domain_name
        self.bucket_name = os.getenv("AIACS_BUCKET_NAME") or bucket_name
        self.disclient_id: Optional[str] = None
        self.disclient_secret: Optional[str] = None
        self.par_url: Optional[str] = None
        self.read_timeout = read_timeout
        self.connect_timeout = connect_timeout
        self.default_timeout = (self.connect_timeout, self.read_timeout)

    def fetch_dis_credentials(
        self, db_client: OracleDatabaseClient
    ) -> tuple[Optional[str], Optional[str]]:
        """
        Fetch DIS client credentials from the connected Oracle database.

        Args:
            db_client (OracleDatabaseClient): Connected Oracle DB client.

        Returns:
            tuple[Optional[str], Optional[str]]: (client_id, client_secret), or (None, None) on failure.
        """
        if not db_client.is_connected or not db_client.connection:
            logger.error("Cannot fetch DIS credentials - not connected to database")
            return None, None
        cursor = db_client.connection.cursor()
        try:
            query = """
                    SELECT
                        V_USERNAME,
                        V_PASSWORD
                    FROM FCC_AIA_CREDENTIALS
                    WHERE V_CREDENTIAL_TYPE='DIS_PARTNER'
                """
            cursor.execute(query)
            results = cursor.fetchall()
            if not results:
                logger.error("No DIS_PARTNER credentials found")
                return None, None
            self.disclient_id, self.disclient_secret = results[0]
            logger.info("Received DIS client credentials")
            return self.disclient_id, self.disclient_secret
        except oracledb.DatabaseError as e:
            logger.error("Database error fetching DIS creds: %s", e)
        except Exception as e:
            logger.error("Unexpected error fetching DIS creds: %s", e)
        finally:
            cursor.close()
        return None, None

    def build_urls(self) -> dict[str, str]:
        """
        Build and return URLs for bearer token and PAR requests in the Oracle object store.

        Returns:
            dict[str, str]: Contains 'bearer_token_url' and 'par_request_url'
        """
        bearer_token_url = f"{self.domain_name}/oauth/token?grant_type=client_credentials"
        par_request_url = (
            f"{self.domain_name}/platform/par/v1/tenant/{self.tenant_id}/bucket/{self.bucket_name}"
        )
        return {"bearer_token_url": bearer_token_url, "par_request_url": par_request_url}

    def get_dis_bearer_token(self, bearer_token_url: str) -> Optional[dict[str, Any]]:
        """
        Retrieve the DIS bearer token for authenticating PAR API requests.

        Args:
            bearer_token_url (str): The URL to request the bearer token from.

        Returns:
            Optional[dict[str, Any]]: The token dict (access_token, expires_in) or None on failure.
        """
        if self.disclient_id is None or self.disclient_secret is None:
            logger.error("DIS client credentials not set for ObjectStoreClient")
            return None
        try:
            response = requests.post(
                bearer_token_url,
                auth=HTTPBasicAuth(self.disclient_id, self.disclient_secret),
                timeout=300,
            )
            response.raise_for_status()
            body = response.json()
            return {"access_token": body.get("access_token"), "expires_in": body.get("expires_in")}
        except Exception as e:
            logger.error("Error fetching DIS Bearer Token: %s", e)
            return None

    def call_par_generator(
        self, par_request_url: str, bearer_token: str, par_req_input: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Make a REST call to Oracle PAR generator endpoint.

        Args:
            par_request_url (str): The PAR generator URL.
            bearer_token (str): Bearer token for authorization.
            par_req_input (dict[str, Any]): Request body as dict.

        Returns:
            dict[str, Any]: JSON response dict or error description.
        """
        headers = {
            "Authorization": f"Bearer {bearer_token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

        try:
            r = requests.post(
                par_request_url,
                json=par_req_input,
                headers=headers,
                timeout=300,
            )
            r.raise_for_status()
            logger.info("Received PAR generator response")
            data: Any = r.json()
            if not isinstance(data, dict):
                logger.error("Unexpected response type from PAR generator (not a JSON object)")
                return {"error": "Unexpected response format"}
            return cast(dict[str, Any], data)

        except requests.RequestException as e:
            logger.error("PAR request error: %s", e)
            return {"error": str(e)}
        except Exception as e:
            logger.error("Unexpected error during PAR request: %s", e)
            return {"error": str(e)}

    def generate_par_url(self, task_id: Optional[str] = None) -> None:
        """
        Generate a new PAR URL for accessing the Oracle object store and update the class par_url.

        Args:
            task_id (Optional[str]): Task identifier. If None, random UUID is generated.

        Returns:
            None
        """
        if not task_id:
            task_id = str(uuid.uuid4()).replace("-", "")
        urls = self.build_urls()
        bearer_response = self.get_dis_bearer_token(urls["bearer_token_url"])
        bearer_token = bearer_response.get("access_token") if bearer_response else None
        if not bearer_token:
            logger.error("Bearer token retrieval failed")
            return None

        expires_at = (datetime.utcnow() + timedelta(hours=8)).strftime("%Y-%m-%dT%H:%M:%SZ")
        par_req_input = {
            "name": task_id,
            "bucketListingAction": "ListObjects",
            "accessType": "AnyObjectReadWrite",
            "timeExpires": expires_at,  # 8h expiration time if based on FCC's code snippet.
        }
        par_response = self.call_par_generator(urls["par_request_url"], bearer_token, par_req_input)
        if isinstance(par_response, dict) and "url" in par_response:
            logger.info("Received PAR URL for task ID %s which expires at %s.", task_id, expires_at)
            self.par_url = par_response["url"]
        else:
            logger.error("Failed to get PAR URL for task ID %s: %s", task_id, par_response)
            self.par_url = None

    def get_file(
        self, relative_path: str, par_url: Optional[str] = None, task_id: Optional[str] = None
    ) -> Optional[str]:
        """
        Download and return file content as a string from object store (or None on error).

        Args:
            relative_path (str): Relative path to the file/object.
            par_url (Optional[str]): Optionally provide a PAR URL (otherwise generated).
            task_id (Optional[str]): Optionally provide the task ID for PAR URL generation.

        Returns:
            Optional[str]: File contents, or None if unavailable.
        """
        if par_url:
            self.par_url = par_url
        else:
            if not self.par_url:
                self.generate_par_url()
        if not self.par_url:
            logger.error("Could not get PAR URL for task_id %s", task_id)
            return None
        download_file_url = self.par_url + relative_path
        try:
            logger.debug("Downloading %s ", relative_path)
            random_sleep = random.uniform(0.05, 0.15)
            time.sleep(random_sleep)  # Because sometimes error: 429 Client Error: Too Many Requests
            response = requests.get(download_file_url, timeout=self.default_timeout)
            if response.status_code == 200:
                response_text = response.text
                if response_text:
                    logger.debug(
                        "Downloaded file '%s' (%d bytes).", relative_path, len(response_text)
                    )
                return response_text
            elif response.status_code == 404:
                logger.warning("File '%s' not found (404).", relative_path)
            else:
                logger.error("Failed to fetch '%s' HTTP %d", relative_path, response.status_code)
        except requests.RequestException as exc:
            logger.exception("Error fetching '%s': %s", relative_path, exc)
        return None

    def get_available_files_per_directory(
        self, par_url: Optional[str] = None, task_id: Optional[str] = None
    ) -> dict[str, list[str]]:
        """
        Retrieve and list all available files in the Oracle Object Store, grouped by directory.

        This function uses a Pre-Authorized Request (PAR) URL to query the object storage bucket
        and fetch a JSON listing of all available objects. It organizes the response by
        directory name (the prefix before the first "/").

        Args:
            par_url (Optional[str]):
                An optional pre-authorized request URL.
                If not provided, a new one will be generated automatically.
            task_id (Optional[str]):
                An optional task identifier used if a new PAR URL must be generated.

        Returns:
            dict[str, list[str]]:
                A dictionary where each key is a directory name and each value is a list of file names.
                Returns an empty dictionary on failure or if no files are available.
        """
        if par_url:
            self.par_url = par_url
        else:
            if not self.par_url:
                self.generate_par_url(task_id)
        if not self.par_url:
            logger.error("Could not get PAR URL for task_id %s", task_id)
            return {}

        try:
            response = requests.get(self.par_url, timeout=self.default_timeout)
            response.raise_for_status()
            data = response.json()
        except Exception as e:
            logger.error("Failed to fetch or parse data: %s", e)
            return {}

        obj_list = data.get("objects", [])
        dir_files_map: dict[str, list[str]] = {}

        for item in obj_list:
            name = item.get("name")
            if not name or "/" not in name:
                continue  # skip invalid or root-level files
            directory, file_name = name.split("/", 1)
            dir_files_map.setdefault(directory, []).append(file_name)

        return dir_files_map


class FileLoader:
    """
    Loads tabular data (CSV), schema (JSON), or other files from Oracle object storage or a local path.
    Uses OracleDatabaseClient and ObjectStoreClient for credentials and object store access.
    """

    def __init__(
        self,
        use_object_store: bool = False,
        obj_stor_connect_timeout: float = 3,
        obj_stor_read_timeout: float = 60,
        obj_store_mappings: Optional[dict[str, dict[str, Any]]] = None,
        local_paths: Optional[dict[str, str]] = None,
    ) -> None:
        """
        Initialize a FileLoader.

        Args:
            use_object_store (bool): If True, use Oracle object store/data APIs; if False, operate in local mode.
            obj_stor_connect_timeout (float):
                Connection timeout (in seconds) for Object Storage requests.
                Defaults to 3 seconds.
            obj_stor_read_timeout (float):
                Read timeout (in seconds) for Object Storage requests.
                Defaults to 60 seconds.
            obj_store_mappings (Optional[dict[str, dict[str, Any]]]):
                Only used optionally when using object store. If not provided, the default mapping will be used.
                The default mapping can be only partially overwritten as well. Note that the keys should match.
                Default mapping:
                {
                    "data_tables_mapping": {
                        "account": {},
                        "customer": {},
                        "transaction": {},
                        "priorCaseInfo": {},
                    },
                    "threshold_tables_mapping": {"metadata": {"SCNRO": "SCNRO.csv", "TSHLD": "TSHLD.csv"}},
                    "tables_schema_mapping": {"metadata": "schema.json"},
                    "knowledge_base_mapping": {"metadata": "knowledge_base.json"},
                }
                More detailed descriptions:
                - data_tables_mapping
                    Nested dictionary where each outer key maps to an object storage folder.
                    Each inner key represents a table name (used as an SQL table name), and
                    its value is the corresponding file name suffix to retrieve from object storage.
                    If the outer value is an empty dictionary, the data retrieval function
                    will automatically determine which files to load.
                    Otherwise, the outer value is a dict[str, str] mapping folder names to file names.
                - threshold_tables_mapping
                    Nested dictionary where the outer key maps to an object storage folder.
                    Each inner key represents a table name (used as an SQL table name),
                    and the corresponding value is the file name to retrieve from object storage.
                - tables_schema_mapping
                    Dictionary mapping object storage folder (key) to the filename to look for (value).
                - knowledge_base_mapping
                    Dictionary mapping object storage folder (key) to the filename to look for (value).

            local_paths (dict[str, str]):
                It holds values of "tables_schema_path", "threshold_tables_path", "knowledge_base_path", "data_tables_path".
                Optional, not needed when using object store but when using local files all keys are mandatory.
        },
        """
        self.use_object_store = use_object_store
        # default mapping
        self.obj_store_mappings: dict[str, dict[str, Any]] = {
            "data_tables_mapping": {
                "account": {},
                "customer": {},
                "transaction": {},
                "priorCaseInfo": {},
            },
            "threshold_tables_mapping": {"metadata": {"SCNRO": "SCNRO.csv", "TSHLD": "TSHLD.csv"}},
            "tables_schema_mapping": {"metadata": "schema.json"},
            "knowledge_base_mapping": {"metadata": "knowledge_base.json"},
        }
        # overwrite with custom config
        if obj_store_mappings:
            for key, mapping in obj_store_mappings.items():
                if mapping is not None:
                    if "metadata" not in mapping:
                        raise KeyError(
                            "Each mapping should be wrapped in a dictionary with 'metdata' key."
                        )

                    if key == "threshold_tables_mapping":
                        # need to ensure the keys are SCNRO and TSHLD
                        if not (
                            "SCNRO" in mapping["metadata"].keys()
                            and "TSHLD" in mapping["metadata"].keys()
                        ):
                            raise KeyError(
                                "For threshold_tables_mapping, the format must be "
                                "{'metadata': {'SCNRO': 'file_name_1'}, 'TSHLD': 'file_name_2'}. "
                                f"(Got {list(mapping['metadata'].keys())} instead)"
                            )

                    self.obj_store_mappings[key] = mapping

        self.db_client: Optional[OracleDatabaseClient] = None
        self.obj_client: Optional[ObjectStoreClient] = None

        if self.use_object_store:
            self.db_client = OracleDatabaseClient()
            self.obj_client = ObjectStoreClient(
                connect_timeout=obj_stor_connect_timeout, read_timeout=obj_stor_read_timeout
            )
            with self.db_client as dbc:
                disclient_id, disclient_secret = self.obj_client.fetch_dis_credentials(dbc)
                if not (disclient_id and disclient_secret):
                    logger.warning("DIS client credentials could not be retrieved or are not set.")

            self.obj_client.generate_par_url()
        elif local_paths:
            self.local_paths = local_paths
        else:
            raise ValueError(
                "Either `use_object_store` needs to True or `local_paths` needs to be passed"
            )

    @staticmethod
    def _are_paths_valid(local_paths: dict[str, str]) -> None:
        required_keys = set(
            [
                "tables_schema_path",
                "threshold_tables_path",
                "knowledge_base_path",
                "data_tables_path",
            ]
        )
        if not required_keys.issubset(given_keys := set(local_paths.keys())):
            raise KeyError(
                "The local_paths object is lacking the following keys: %s",
                required_keys - given_keys,
            )
        for key in required_keys:
            path_str = local_paths[key]
            path = Path(str(path_str))
            if not path.exists():
                raise FileNotFoundError("Required path for %s does not exist: %s", key, path_str)
            if path.is_dir() and not any(path.iterdir()):
                logger.warning("Directory for %s is empty: %s", key, path)

    @classmethod
    def from_rfv_config(cls, rfv_config: "RedFlagVerificationConfig") -> "FileLoader":
        if rfv_config["use_object_store"]:
            return FileLoader(
                use_object_store=rfv_config["use_object_store"],
                obj_stor_connect_timeout=rfv_config.get("obj_stor_connect_timeout") or 3,
                obj_stor_read_timeout=rfv_config.get("obj_stor_read_timeout") or 60,
                obj_store_mappings={
                    k: cast(dict[str, Any], rfv_config.get(k))
                    for k in rfv_config.keys()
                    if k.endswith("_mapping") and rfv_config.get(k) is not None
                },
            )
        else:
            local_paths = {
                k: cast(str, rfv_config.get(k, ""))
                for k in rfv_config.keys()
                if k.endswith("_path")
            }
            FileLoader._are_paths_valid(local_paths)
            return FileLoader(
                use_object_store=rfv_config["use_object_store"],
                local_paths=local_paths,
            )

    def __del__(self) -> None:
        """
        Destructor: close any open database connection.

        Returns:
            None
        """
        if self.db_client:
            self.db_client.close()

    def _derive_table_name_from_filename(self, fname: str, case_id: str) -> Optional[str]:
        prefix = f"{case_id}_"
        if not fname.startswith(prefix):
            return None
        without_prefix = fname[len(prefix) :]
        # If something like 'ACC.v2.csv', stem is 'ACC.v2'
        table = Path(without_prefix).stem
        return table or None

    def get_data_tables(self, case_id: Optional[str] = None) -> dict[str, str]:
        """
        Return a dictionary of table data, mapping table names to CSV content.

        Args:
            case_id (Optional[str]): Case ID of the dataset, needed when retrieving from data store.

        Returns:
            dict[str, str]: Maps logical table names to raw CSV content.
        """
        folder_file_mapping: dict[str, dict[str, str]] = self.obj_store_mappings[
            "data_tables_mapping"
        ]
        data_tables: dict[str, str] = {}

        if self.use_object_store and self.obj_client:
            if not case_id:
                raise ValueError(
                    "case_id is required when retrieving from data store (use_object_store=True)."
                )
            data_tables = self._get_data_tables_from_obj_store(case_id, folder_file_mapping)
        else:
            data_tables = self._get_data_tables_from_local(case_id)

        return data_tables

    def _get_data_tables_from_local(self, case_id: Optional[str] = None) -> dict[str, str]:
        """
        Load CSV data tables from a local dataset directory.

        This function reads all CSV files from the directory specified by the
        `RED_FLAG_VERIFICATION_PLANNER_DATASET` environment variable. When a
        `case_id` is provided, only files whose names begin with that case ID
        (e.g., `<case_id>_ACCOUNT.csv`) are loaded. Otherwise, all CSV files in
        the directory are read and returned.

        Args:
            case_id (Optional[str]):
                Case identifier used to filter files by prefix. If not provided,
                all available CSV files in the directory are loaded.

        Returns:
            dict[str, str]:
                A dictionary mapping table names (derived from filenames) to their
                raw CSV file contents.
        """
        data_tables: dict[str, str] = {}
        logger.debug(
            "Reading data tables from local environment (%s)", self.local_paths["data_tables_path"]
        )
        planner_dir = Path(self.local_paths["data_tables_path"])

        if case_id:
            for file_path in planner_dir.glob("*.csv"):
                fname = file_path.name
                if not fname.startswith(f"{case_id}_"):
                    continue
                table_name = self._derive_table_name_from_filename(fname, case_id)
                if not table_name:
                    continue
                try:
                    text = file_path.read_text(encoding="utf-8")
                    key = file_path.stem.split("_", maxsplit=1)[1]
                    data_tables[key] = text
                    logger.debug("Loaded local table '%s' (%d bytes).", key, len(text))
                except Exception as exc:
                    logger.exception("Error reading local CSV %s: %s", fname, exc)
        else:  # for e2e tests, loading without case id
            for file in planner_dir.glob("*.csv"):
                try:
                    text = file.read_text(encoding="utf-8")
                    key = file.stem
                    data_tables[key] = text
                    logger.debug("Loaded local table '%s' (%d bytes).", key, len(text))
                except Exception as exc:
                    logger.exception("Error reading local CSV %s: %s", file, exc)
        return data_tables

    def _get_data_tables_from_obj_store(
        self,
        case_id: str,
        folder_file_mapping: dict[str, dict[str, str]],
    ) -> dict[str, str]:
        """
        Retrieve case-specific CSV data tables content from the Oracle Object Store.

        This function accesses an Oracle Object Storage bucket through a configured
        `ObjectStoreClient` and loads all relevant CSV files based on the provided
        folder-to-file mapping. The mapping can define either explicit file names or
        be left empty for automatic discovery of files matching the given case ID.

        Args:
            case_id (str):
                Unique case identifier used as a filename prefix when filtering
                and matching data files within object storage.
            folder_file_mapping (dict[str, dict[str, Any]]):
                Nested dictionary where each outer key maps to an object storage folder.
                Each inner key represents a table name (used as an SQL table name), and
                its value is the corresponding file suffix to retrieve
                from object storage.
                - If the inner dictionary is empty (`{}`), the method will automatically
                discover and load all files in that folder whose names start with
                the provided `case_id`.
                - If populated, the method will fetch files explicitly by the
                defined mapping (e.g., `{"account": "_ACC.csv"}`).

        Returns:
            dict[str, str]:
                A dictionary mapping table names to their raw CSV file contents.
        """
        data_tables: dict[str, str] = {}
        if self.obj_client is None:
            raise RuntimeError("ObjectStoreClient is not initialized.")
        try:
            available_dir_files_map = self.obj_client.get_available_files_per_directory() or {}
        except Exception as e:
            logger.error("Unexpected error while listing obj storage files: %s", e)
            available_dir_files_map = {}
        if len(available_dir_files_map) == 0:  # early exit on error or empty storage
            return data_tables

        for folder, spec in folder_file_mapping.items():
            # Auto-discover (empty dict)
            if isinstance(spec, dict) and len(spec) == 0:
                files_in_dir = available_dir_files_map.get(folder, [])
                if not files_in_dir:
                    logger.debug("No files listed for folder '%s' during auto-discover.", folder)
                    continue
                for fname in files_in_dir:
                    if not fname.startswith(f"{case_id}_"):
                        continue
                    table_name = self._derive_table_name_from_filename(fname, case_id)
                    if not table_name:
                        continue
                    relative_path = f"{folder}/{fname}"
                    try:
                        response_text = self.obj_client.get_file(relative_path)
                        if response_text:
                            data_tables[table_name] = response_text
                            logger.debug("Auto-loaded '%s' from %s.", table_name, relative_path)
                        else:
                            logger.debug("No content for %s", relative_path)
                    except Exception as exc:
                        logger.exception("Error fetching %s: %s", relative_path, exc)

            # Explicit mapping (dict with items)
            elif isinstance(spec, dict) and len(spec) > 0:
                for table_name, file_suffix in spec.items():
                    if not isinstance(file_suffix, str):
                        logger.warning(
                            "Skipping non-string file_suffix for table '%s' in folder '%s': %r",
                            table_name,
                            folder,
                            file_suffix,
                        )
                        continue
                    filename = f"{case_id}{file_suffix}"
                    relative_path = f"{folder}/{filename}"
                    try:
                        response_text = self.obj_client.get_file(relative_path)
                        if response_text:
                            data_tables[table_name] = response_text
                        else:
                            logger.debug("No content for %s", relative_path)
                    except Exception as exc:
                        logger.exception("Error fetching %s: %s", relative_path, exc)

            else:
                logger.warning(
                    "Unrecognized mapping spec for folder '%s': %r (expected dict or str). Skipping.",
                    folder,
                    spec,
                )
        return data_tables

    def get_threshold_tables(self) -> dict[str, str]:
        """
        Return a dictionary mapping threshold table names to their CSV content.
        Content retrieved either from the Oracle Object Store or from local directories.

        Returns:
            dict[str, str]:
                Dictionary mapping table names to their content.
        """
        folder_file_mapping: dict[str, dict[str, str]] = self.obj_store_mappings[
            "threshold_tables_mapping"
        ]
        threshold_tables: dict[str, str] = {}

        if self.use_object_store and self.obj_client:
            for folder, table_file_names in folder_file_mapping.items():
                for table_name, file_name in table_file_names.items():
                    relative_path = f"{folder}/{file_name}"
                    response_text = self.obj_client.get_file(relative_path)
                    if response_text:
                        threshold_tables[table_name] = response_text
        else:
            logger.debug("Reading threshold tables from local environment")
            threshold_dir = Path(self.local_paths["threshold_tables_path"])

            for file in threshold_dir.glob("*.csv"):
                try:
                    text = file.read_text(encoding="utf-8")
                    key = file.stem
                    threshold_tables[key] = text
                    logger.debug("Loaded local table '%s' (%d bytes).", key, len(text))
                except Exception as exc:
                    logger.exception("Error reading local CSV %s: %s", file, exc)
        return threshold_tables

    def get_tables_schema(self) -> dict[str, Any]:
        """
        Return the tables schema as a dictionary loaded from JSON.
        Content retrieved either from the Oracle Object Store or from local directories.

        Returns:
            dict[str, Any]: Parsed schema from JSON.
        """
        schema: Optional[dict[str, str]] = None
        folder_file_mapping: dict[str, str] = self.obj_store_mappings["tables_schema_mapping"]

        if self.use_object_store and self.obj_client:
            for folder, filename in folder_file_mapping.items():
                relative_path = f"{folder}/{filename}"
                response_text = self.obj_client.get_file(relative_path)
                if response_text:
                    try:
                        schema = json.loads(response_text)
                    except json.JSONDecodeError as exc:
                        logger.error("Failed to parse JSON schema: %s", exc)
                        raise
        else:
            logger.debug("Fetching tables schema from %s", self.local_paths["tables_schema_path"])
            schema_file_path = Path(self.local_paths["tables_schema_path"])
            try:
                logger.debug("Reading schema JSON from %s", schema_file_path)
                text = schema_file_path.read_text(encoding="utf-8")
                schema = json.loads(text)
                logger.debug("Loaded JSON schema file (%d bytes)", len(text))
            except json.JSONDecodeError as exc:
                logger.exception("Error decoding JSON from %s: %s", schema_file_path, exc)
                raise
            except Exception as exc:
                logger.exception("Error reading schema JSON file %s: %s", schema_file_path, exc)
                raise

        if schema is None:
            raise ValueError("Schema could not be loaded.")
        return schema

    def get_knowledge_base(self) -> list[dict[str, Any]]:
        """
        Return the memory file (knowledge base) as a dictionary loaded from JSON.
        Content retrieved either from the Oracle Object Store or from local directories.

        Returns:
            list[dict[str, Any]]: Parsed memory file from JSON.
        """
        knowledge_base: list[dict[str, Any]] = []
        folder_file_mapping: dict[str, str] = self.obj_store_mappings["knowledge_base_mapping"]

        if self.use_object_store and self.obj_client:
            for folder, filename in folder_file_mapping.items():
                relative_path = f"{folder}/{filename}"
                response_text = self.obj_client.get_file(relative_path)
                if response_text:
                    try:
                        knowledge_base = json.loads(response_text)
                    except json.JSONDecodeError as exc:
                        logger.error("Failed to parse JSON knowledge base: %s", exc)
                        raise
        else:
            logger.debug("Fetching knowledge base from %s", self.local_paths["knowledge_base_path"])
            knowledge_base_file_path = Path(self.local_paths["knowledge_base_path"])
            try:
                logger.debug("Reading knowledge base JSON from %s", knowledge_base_file_path)
                text = knowledge_base_file_path.read_text(encoding="utf-8")
                knowledge_base = json.loads(text)
                logger.debug("Loaded JSON knowledge base file (%d bytes)", len(text))
            except json.JSONDecodeError as exc:
                logger.exception("Error decoding JSON from %s: %s", knowledge_base_file_path, exc)
                raise
            except Exception as exc:
                logger.exception(
                    "Error reading knowledge base JSON file %s: %s", knowledge_base_file_path, exc
                )
                raise

        if knowledge_base is None:
            raise ValueError("knowledge base could not be loaded.")
        return knowledge_base
