# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

import os
from typing import Any, Optional

import numpy as np

from wayflowcore.embeddingmodels import OCIGenAIEmbeddingModel
from wayflowcore.models.ociclientconfig import OCIClientConfigWithApiKey

OCIGENAI_ENDPOINT = "https://inference.generativeai.us-chicago-1.oci.oraclecloud.com"


def get_embed_model(
    model_id: str = "cohere.embed-english-v3.0", compartment_id: Optional[str] = None
) -> OCIGenAIEmbeddingModel:
    if not compartment_id:
        compartment_id = os.getenv("OCI_COMPARTMENT_ID")
    if isinstance(compartment_id, str):
        oci_embedding_model = OCIGenAIEmbeddingModel(
            model_id=model_id,
            config=OCIClientConfigWithApiKey(
                service_endpoint=OCIGENAI_ENDPOINT,
                compartment_id=compartment_id or os.getenv("OCI_COMPARTMENT_ID", "dd"),
            ),
        )
    else:
        raise TypeError("No Valid Compartment ID")
    return oci_embedding_model


def similarity(vector1: Any, vector2: Any) -> Any:
    return np.dot(vector1, vector2) / (np.linalg.norm(vector1) * np.linalg.norm(vector2))
