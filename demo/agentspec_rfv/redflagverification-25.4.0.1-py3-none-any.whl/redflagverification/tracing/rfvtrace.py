# Copyright (C) 2024, 2025 Oracle and/or its affiliates. All rights reserved.
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Iterable, Iterator

from wayflowcore.tracing.spanprocessor import SpanProcessor
from wayflowcore.tracing.trace import Trace

_RFV_DEBUG: ContextVar[bool] = ContextVar("_RFV_DEBUG", default=False)


def debug_enabled() -> bool:
    return _RFV_DEBUG.get()


@contextmanager
def RFVDebugContext(debug: bool) -> Iterator[None]:
    token = _RFV_DEBUG.set(bool(debug))
    try:
        yield
    finally:
        _RFV_DEBUG.reset(token)


@contextmanager
def RFVTrace(*, debug: bool = False, span_processors: Iterable[SpanProcessor]) -> Iterator[None]:
    with RFVDebugContext(debug):
        with Trace(span_processors=list(span_processors)):
            yield
