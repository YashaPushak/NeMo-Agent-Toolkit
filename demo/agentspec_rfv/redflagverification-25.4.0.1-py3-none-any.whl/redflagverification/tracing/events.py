# Copyright (C) 2024, 2025 Oracle and/or its affiliates. All rights reserved.

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from wayflowcore._utils.dataclass_utils import _required_attribute
from wayflowcore.events.event import EndSpanEvent, StartSpanEvent

if TYPE_CHECKING:
    from redflagverification.tracing.spans import (  # noqa: F401
        PlannerSpan,
        QuestionReformulationSpan,
    )


@dataclass(frozen=True)
class QuestionReformulationStartEvent(StartSpanEvent["QuestionReformulationSpan"]):
    """
    This event is recorded when the question reformulation stage starts.
    """

    red_flag: str = field(default_factory=_required_attribute("red_flag", "str"))
    customer_id: str = field(default_factory=_required_attribute("customer_id", "str"))
    investigation_period: str = field(
        default_factory=_required_attribute("investigation_period", "str")
    )
    scenario: str = field(default_factory=_required_attribute("scenario", "str"))

    def to_tracing_info(self, mask_sensitive_information: bool = True) -> dict[str, Any]:
        return {
            **super().to_tracing_info(mask_sensitive_information=mask_sensitive_information),
            "red_flag": self.red_flag,
            "customer_id": self.customer_id,
            "investigation_period": self.investigation_period,
            "scenario": self.scenario,
        }


@dataclass(frozen=True)
class QuestionReformulationEndEvent(EndSpanEvent["QuestionReformulationSpan"]):
    """
    This event is recorded when the llm generates a response.
    """

    retrieved_threshold_rows: str = field(
        default_factory=_required_attribute("retrieved_threshold_rows", "str")
    )
    initial_reformulation: str = field(
        default_factory=_required_attribute("initial_reformulation", "str")
    )
    clarification_question_answer: list[dict[str, Any]] = field(
        default_factory=_required_attribute("clarification_question_answer", "list[dict[str, Any]]")
    )
    final_reformulation: str = field(
        default_factory=_required_attribute("final_reformulation", "str")
    )
    successful_reformulation: bool = field(
        default_factory=_required_attribute("successful_reformulation", "bool")
    )
    llm_call_stats: list[dict[str, Any]] = field(
        default_factory=_required_attribute("llm_call_stats", "list[dict[str, Any]]")
    )
    total_stats: dict[str, Any] = field(
        default_factory=_required_attribute("total_stats", "dict[str, Any]")
    )

    def to_tracing_info(self, mask_sensitive_information: bool = True) -> dict[str, Any]:
        return {
            **super().to_tracing_info(mask_sensitive_information=mask_sensitive_information),
            "retrieved_threshold_rows": self.retrieved_threshold_rows,
            "initial_reformulation": self.initial_reformulation,
            "clarification_question_answer": self.clarification_question_answer,
            "final_reformulation": self.final_reformulation,
            "successful_reformulation": self.successful_reformulation,
            "llm_call_stats": self.llm_call_stats,
            "total_stats": self.total_stats,
        }


@dataclass(frozen=True)
class PlannerStartEvent(StartSpanEvent["PlannerSpan"]):
    """
    This event is recorded when the planner stage starts.
    """

    def to_tracing_info(self, mask_sensitive_information: bool = True) -> dict[str, Any]:
        return {
            **super().to_tracing_info(mask_sensitive_information=mask_sensitive_information),
        }


@dataclass(frozen=True)
class PlannerEndEvent(EndSpanEvent["PlannerSpan"]):
    """
    This event is recorded when the planner finishes the plan generation + execution.
    """

    plan: list[str] = field(default_factory=_required_attribute("plan", "list[str]"))
    steps_execution: list[dict[str, Any]] = field(
        default_factory=_required_attribute("steps_execution", "list[dict[str, Any]]")
    )
    llm_call_stats: list[dict[str, Any]] = field(
        default_factory=_required_attribute("llm_call_stats", "list[dict[str, Any]]")
    )
    total_stats: dict[str, Any] = field(
        default_factory=_required_attribute("total_stats", "dict[str, Any]")
    )

    def to_tracing_info(self, mask_sensitive_information: bool = True) -> dict[str, Any]:
        return {
            **super().to_tracing_info(mask_sensitive_information=mask_sensitive_information),
            "plan": self.plan,
            "steps_execution": self.steps_execution,
            "llm_call_stats": self.llm_call_stats,
            "total_stats": self.total_stats,
        }
