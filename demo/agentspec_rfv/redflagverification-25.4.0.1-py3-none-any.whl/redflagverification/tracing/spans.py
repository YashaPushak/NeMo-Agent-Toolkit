# Copyright (C) 2024, 2025 Oracle and/or its affiliates. All rights reserved.
import logging
from dataclasses import dataclass, field
from typing import Any, cast

from redflagverification.stages.constants import ANSWER_QUESTION
from redflagverification.tracing.events import (
    PlannerEndEvent,
    PlannerStartEvent,
    QuestionReformulationEndEvent,
    QuestionReformulationStartEvent,
)
from redflagverification.tracing.rfvtrace import debug_enabled
from wayflowcore._utils.dataclass_utils import _required_attribute
from wayflowcore.events.event import (
    Event,
    FlowExecutionIterationFinishedEvent,
    LlmGenerationResponseEvent,
    ToolExecutionResultEvent,
)
from wayflowcore.models.llmmodel import LlmCompletion
from wayflowcore.tracing.span import (
    FlowExecutionSpan,
    LlmGenerationSpan,
    Span,
    ToolExecutionSpan,
)

logger = logging.getLogger(__name__)


def _get_total_stats(llm_call_stats: list[dict[str, Any]]) -> dict[str, Any]:
    total_stats = {}
    for stat in llm_call_stats:
        mid = stat["model_id"]
        if mid not in total_stats:
            total_stats[mid] = {
                "execution_time(s)": 0.0,
                "input_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0,
            }
        total_stats[mid]["execution_time(s)"] += stat["execution_time(s)"]
        total_stats[mid]["input_tokens"] += stat["input_tokens"]
        total_stats[mid]["output_tokens"] += stat["output_tokens"]
        total_stats[mid]["total_tokens"] += stat["total_tokens"]
    return total_stats


def _extract_llm_outputs(completion: LlmCompletion) -> list[str]:
    outputs: list[str] = []
    msg = getattr(completion, "message", None)
    contents = getattr(msg, "contents", None)
    if isinstance(contents, list):
        for item in contents:
            text = getattr(item, "content", None)
            if isinstance(text, str):
                outputs.append(text)
    return outputs


@dataclass
class QuestionReformulationSpan(Span):
    """Span for the question reformulation stage of the red flag verification step"""

    red_flag: str = field(default_factory=_required_attribute("red_flag", "str"))
    customer_id: str = field(default_factory=_required_attribute("customer_id", "str"))
    investigation_period: str = field(
        default_factory=_required_attribute("investigation_period", "str")
    )
    scenario: str = field(default_factory=_required_attribute("scenario", "str"))

    def _get_slim_trace(self, mask_sensitive_information: bool = False) -> dict[str, Any]:
        attributes_to_pop = ["event_id", "timestamp", "name", "event_type"]
        input_logs = self.events[0].to_tracing_info(
            mask_sensitive_information=mask_sensitive_information
        )
        output_logs = self.events[-1].to_tracing_info(
            mask_sensitive_information=mask_sensitive_information
        )
        for attribute_to_pop in attributes_to_pop:
            input_logs.pop(attribute_to_pop)
            output_logs.pop(attribute_to_pop)
        return input_logs | output_logs

    def _create_start_span_event(self) -> Event:
        return QuestionReformulationStartEvent(
            span=self,
            red_flag=self.red_flag,
            customer_id=self.customer_id,
            investigation_period=self.investigation_period,
            scenario=self.scenario,
        )

    def _get_tool_result_from_event_list(self, events: list[Event]) -> Any:
        return (
            events[-1].tool_result.content
            if isinstance(events[-1], ToolExecutionResultEvent)
            else None
        )

    def record_end_span_event(
        self,
        spans: list[Span],
    ) -> None:
        """
        Record a QuestionReformulationEndEvent with the given information
        as the closing event for this Span.
        Note that this method is supposed to be called only once per Span instance.
        """
        initial_reformulation, final_reformulation = "", ""
        clarification_question_answer = {}
        llm_call_stats = []
        successful_reformulation = True
        # look for the information we want
        for span in spans[:-1]:
            if isinstance(span, ToolExecutionSpan) and span.tool.name == "execute_query_tool":
                retrieved_threshold_rows = self._get_tool_result_from_event_list(span.events)
            elif isinstance(span, ToolExecutionSpan) and span.tool.name == "is_undetermined":
                successful_reformulation = self._get_tool_result_from_event_list(span.events).get(
                    "successful_reformulation"
                )
            elif isinstance(span, ToolExecutionSpan) and span.tool.name == "regex_extraction":
                if any(
                    [
                        "Reformulated question" in prop.default_value
                        for prop in cast(Any, span.events[-1]).tool.input_descriptors
                        if isinstance(prop.default_value, str)
                    ]
                ):
                    if initial_reformulation == "":
                        initial_reformulation = cast(Any, span.events[-1]).tool_result.content
                    else:
                        final_reformulation = cast(Any, span.events[-1]).tool_result.content
            elif isinstance(span, FlowExecutionSpan):
                for event in span.events:
                    if isinstance(event, FlowExecutionIterationFinishedEvent):
                        info = {
                            "question": event.execution_state._flow_output_value_dict[
                                "question_io"
                            ],
                            "search_result": event.execution_state._flow_output_value_dict[
                                "search_result"
                            ],
                            "answer": event.execution_state._flow_output_value_dict[
                                ANSWER_QUESTION
                            ],
                            "undetermined": event.execution_state._flow_output_value_dict[
                                "q_regex_output"
                            ]
                            == "0",
                        }
                        clarification_question_answer[info["question"]] = info
            elif isinstance(span, LlmGenerationSpan):
                event = cast(LlmGenerationResponseEvent, span.events[-1])
                completion: LlmCompletion = event.completion
                token_usage = completion.token_usage
                start_time = span.start_time or 0
                end_time = span.end_time or 0
                execution_time = (end_time - start_time) / 1e9  # ns -> s
                stats = {
                    "execution_time(s)": execution_time,
                    "model_id": span.llm.model_id,
                    "input_tokens": token_usage.input_tokens if token_usage else 0,
                    "output_tokens": token_usage.output_tokens if token_usage else 0,
                    "total_tokens": token_usage.total_tokens if token_usage else 0,
                }
                # In debug mode: add the raw LLM outputs
                if debug_enabled():
                    stats["llm_outputs"] = _extract_llm_outputs(completion)

                llm_call_stats.append(stats)

        # If there were no clarifications, treat the initial as the final
        if not clarification_question_answer and initial_reformulation and not final_reformulation:
            final_reformulation = initial_reformulation

        total_stats = _get_total_stats(llm_call_stats)
        self._record_end_span_event(
            event=QuestionReformulationEndEvent(
                span=self,
                retrieved_threshold_rows=retrieved_threshold_rows,
                initial_reformulation=initial_reformulation,
                clarification_question_answer=list(clarification_question_answer.values()),
                final_reformulation=final_reformulation,
                successful_reformulation=successful_reformulation,
                llm_call_stats=llm_call_stats,
                total_stats=total_stats,
            )
        )


@dataclass
class PlannerSpan(Span):
    """
    Span for the ModularDatabasePlanner stage (plan generation + per-step execution).
    """

    def _get_slim_trace(self, mask_sensitive_information: bool = False) -> dict[str, Any]:
        attributes_to_pop = ["event_id", "timestamp", "name", "event_type"]
        input_logs = self.events[0].to_tracing_info(
            mask_sensitive_information=mask_sensitive_information
        )
        output_logs = self.events[-1].to_tracing_info(
            mask_sensitive_information=mask_sensitive_information
        )
        for attribute_to_pop in attributes_to_pop:
            input_logs.pop(attribute_to_pop, None)
            output_logs.pop(attribute_to_pop, None)
        return input_logs | output_logs

    def _create_start_span_event(self) -> Event:
        return PlannerStartEvent(span=self)

    def _get_finished_events(
        self, spans: list["Span"]
    ) -> list[FlowExecutionIterationFinishedEvent]:
        finished_events: list[FlowExecutionIterationFinishedEvent] = []
        for s in spans:
            if isinstance(s, FlowExecutionSpan):
                finished_events.extend(
                    ev for ev in s.events if isinstance(ev, FlowExecutionIterationFinishedEvent)
                )
        return finished_events

    def _module_from_history(self, step_history: list[str]) -> str:
        if "retriever_execution_step" in step_history:
            return "Retriever"
        if "informer_execution_step" in step_history:
            return "Informer"
        if "executor_execution_step" in step_history:
            return "Executor"
        return ""

    def _fingerprint_dispatcher_row(
        self, step_history: list[str], step_io: str | None, module_output: str | None
    ) -> str:
        import hashlib

        fp_src = f"{step_history}|{step_io}|{module_output}"
        return hashlib.md5(fp_src.encode("utf-8", errors="ignore")).hexdigest()

    def record_end_span_event(
        self,
        spans: list["Span"],
    ) -> None:
        plan_steps: list[str] = []
        steps_execution: list[dict[str, Any]] = []
        llm_call_stats: list[dict[str, Any]] = []
        seen_dispatcher_fps: set[str] = set()

        for span in spans:
            if isinstance(span, ToolExecutionSpan) and span.tool.name == "regex_extraction":
                if any(
                    [
                        "##\\[((?:.|\\r?\\n)*?)\\]##" in prop.default_value
                        for prop in cast(Any, span.events[-1]).tool.input_descriptors
                        if isinstance(prop.default_value, str)
                    ]
                ):
                    plan_candidate = (
                        cast(Any, span.events[-1]).tool_result.content if span.events else None
                    )
                    if isinstance(plan_candidate, list) and plan_candidate:
                        plan_steps = plan_candidate
                        break

        finished_events = self._get_finished_events(spans)
        for ev in finished_events:
            state = ev.execution_state._flow_output_value_dict
            step_history = getattr(ev.execution_state, "step_history", [])
            # dispatcher FinishedEvents: exported multiple times with identical content
            # we dedupe by a fingerprint of (step_history, step_io, output) so each step appears once
            if "module_extraction_step" in step_history and "branching_step" in step_history:
                step_io = state.get("step_io")
                module_output = state.get("output")
                fp = self._fingerprint_dispatcher_row(step_history, step_io, module_output)
                if fp in seen_dispatcher_fps:
                    continue
                seen_dispatcher_fps.add(fp)
                module = self._module_from_history(step_history)
                steps_execution.append(
                    {
                        "module": module,
                        "step": step_io,
                        "output": module_output,
                    }
                )
        for s in spans:
            if isinstance(s, LlmGenerationSpan):
                event = cast(LlmGenerationResponseEvent, s.events[-1])
                completion: LlmCompletion = event.completion
                token_usage = completion.token_usage
                start_time = s.start_time or 0
                end_time = s.end_time or 0
                execution_time = (end_time - start_time) / 1e9  # ns -> s
                stats = {
                    "execution_time(s)": execution_time,
                    "model_id": s.llm.model_id,
                    "input_tokens": token_usage.input_tokens if token_usage else 0,
                    "output_tokens": token_usage.output_tokens if token_usage else 0,
                    "total_tokens": token_usage.total_tokens if token_usage else 0,
                }
                # In debug mode: add the raw LLM outputs
                if debug_enabled():
                    stats["llm_outputs"] = _extract_llm_outputs(completion)

                llm_call_stats.append(stats)
        total_stats = _get_total_stats(llm_call_stats)
        self._record_end_span_event(
            event=PlannerEndEvent(
                span=self,
                plan=plan_steps,
                steps_execution=steps_execution,
                llm_call_stats=llm_call_stats,
                total_stats=total_stats,
            )
        )
