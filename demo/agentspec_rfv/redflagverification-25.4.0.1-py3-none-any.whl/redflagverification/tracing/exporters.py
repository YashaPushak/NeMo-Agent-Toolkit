# Copyright (C) 2024, 2025 Oracle and/or its affiliates. All rights reserved.

from wayflowcore.tracing.span import (
    FlowExecutionSpan,
    LlmGenerationSpan,
    Span,
    ToolExecutionSpan,
)
from wayflowcore.tracing.spanexporter import SpanExporter


class InMemoryExporter(SpanExporter):
    def __init__(self) -> None:
        self.span_list: list[Span] = []

    def export(self, spans: list[Span], mask_sensitive_information: bool = True) -> None:
        for span in spans:
            if any(
                isinstance(span, span_of_interest)
                for span_of_interest in [ToolExecutionSpan, LlmGenerationSpan, FlowExecutionSpan]
            ):
                self.span_list.append(span)

    def startup(self) -> None:
        pass

    def shutdown(self) -> None:
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        self.span_list = []
        return True
