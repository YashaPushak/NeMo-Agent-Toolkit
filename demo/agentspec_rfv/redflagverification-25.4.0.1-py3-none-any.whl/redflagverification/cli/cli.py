# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

import logging
from argparse import ArgumentParser

from redflagverification.cli import query_database, verify_red_flag


def _get_parser() -> ArgumentParser:
    cli = ArgumentParser()
    subparsers = cli.add_subparsers(dest="command")

    # Register example command
    verifredflag = subparsers.add_parser("verify_red_flag", help="Investigates a red flag")
    verify_red_flag.configure(verifredflag)
    verifredflag.set_defaults(func=verify_red_flag.invoke)

    ask_database = subparsers.add_parser("query_database", help="Ask a question about a database")
    query_database.configure(ask_database)
    ask_database.set_defaults(func=query_database.invoke)

    return cli


def main() -> None:
    logging.basicConfig(level=logging.INFO)

    parser = _get_parser()

    args, _ = parser.parse_known_args()

    if not args.command:
        parser.print_help()
        parser.exit(1)
    else:
        args.func(args)


if __name__ == "__main__":
    main()
