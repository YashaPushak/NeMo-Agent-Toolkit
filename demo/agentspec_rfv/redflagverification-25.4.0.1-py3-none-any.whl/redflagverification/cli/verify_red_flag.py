# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

import argparse
import asyncio
import logging
from typing import cast

from redflagverification.helpers.file_loader import FileLoader
from redflagverification.helpers.llm_helper import get_llm
from redflagverification.helpers.schema import format_schema_str
from redflagverification.stages.modular_db_query.planner import ModularDatabasePlanner
from redflagverification.stages.query_reformulation_stage.statement_reformulation import (
    parse_reformulation_trace,
    run_question_reformulation,
)
from redflagverification.tracing.rfvtrace import RFVDebugContext


def setup_logging(log_file: str = "log.log", root_level: int = logging.DEBUG) -> None:
    logger = logging.getLogger()
    logger.setLevel(root_level)

    # Clear any existing handlers
    if logger.hasHandlers():
        logger.handlers.clear()

    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(root_level)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)

    # Create formatter and add it to the handlers
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(funcName)s - %(levelname)s - %(message)s"
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # Add handlers to the root logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    logging.info(f"Logging initialized. Writing to {log_file}")


def configure(parser: argparse.ArgumentParser) -> None:
    """Configure the argument parser for this subcommand

    Args:
        parser (argparse.ArgumentParser): argument parser of subcommand
    """
    parser.add_argument(
        "--redflag", "-rf", type=str, help="Red Flag to be investigated", required=True
    )
    parser.add_argument("--cust_id", "-ci", type=str, help="Customer ID", required=True)
    parser.add_argument(
        "--period", "-p", type=str, help="Period that should be investigated", required=True
    )
    parser.add_argument(
        "--scenario", "-sn", type=str, help="Scenario of the red flag", required=True
    )

    parser.add_argument(
        "--schema_file_path",
        type=str,
        help="Path of the json file that contains schema description information.",
        default="data/schema.json",
        required=False,
    )
    parser.add_argument(
        "--planner_tables_path",
        "-dataset_path",
        type=str,
        help="Path of the planner queried database",
        default="data/planner_tables",
        required=False,
    )
    parser.add_argument(
        "--memory_file_path",
        "-mem_file_path",
        type=str,
        help="Path of the json file that contains memory",
        default="data/knowledge_base.json",
        required=False,
    )
    parser.add_argument(
        "--thresholds_tables_path",
        "-ths_path",
        type=str,
        help="Path of the folder that contains THRESHOLDS csvs (not recommended to change)",
        default="data/thresholds_tables",
        required=False,
    )
    parser.add_argument(
        "--log_file",
        "-log",
        type=str,
        help="logging file",
        default="",
        required=False,
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        default=False,
        help="Enable verbose RFV tracing (LLM I/O)",
    )


def invoke(args: argparse.Namespace) -> None:
    """Invoke logic of command

    Args:
        src_file (str):
    """
    statement = args.redflag
    scenario = args.scenario
    customer_id = args.cust_id
    period = args.period
    log_file = args.log_file

    file_paths = {
        "tables_schema_path": args.schema_file_path,
        "data_tables_path": args.planner_tables_path,
        "threshold_tables_path": args.thresholds_tables_path,
        "knowledge_base_path": args.memory_file_path,
    }

    if log_file != "":
        setup_logging(log_file)
    else:
        setup_logging()

    file_loader = FileLoader(use_object_store=False, local_paths=file_paths)
    schema_json = file_loader.get_tables_schema()
    schema_description = format_schema_str(schema_json)
    threshold_tables = file_loader.get_threshold_tables()
    knowledge_base = file_loader.get_knowledge_base()

    llm_master = get_llm(ocigenai_model="openai.o3")
    llm_question = get_llm(ocigenai_model="meta.llama-3.3-70b-instruct")

    with RFVDebugContext(args.debug):
        reformulation_trace = cast(
            dict[str, object],
            asyncio.run(
                run_question_reformulation(
                    tables=schema_description,
                    statement=statement,
                    scenario=scenario,
                    llm_master=llm_master,
                    llm_question=llm_question,
                    customer_id=customer_id,
                    period=period,
                    threshold_tables=threshold_tables,
                    knowledge_base=knowledge_base,
                )
            ),
        )

        print(reformulation_trace)
        question, is_undetermined, clarification_questions, successful_reformulation = (
            parse_reformulation_trace(reformulation_trace)
        )

        llm = get_llm(ocigenai_model="openai.o3")
        if isinstance(question, str):
            data_tables = file_loader.get_data_tables()
            planner = ModularDatabasePlanner(
                llm=llm,
                question=question,
                tables=schema_description,
                data_tables=data_tables,
                red_flag=statement,
                scenario=scenario,
                is_undetermined=is_undetermined,
                clarification_questions=clarification_questions,
            )
        else:
            raise TypeError("question is not a string")

        planner_trace = asyncio.run(planner.run())
        print(planner_trace)
