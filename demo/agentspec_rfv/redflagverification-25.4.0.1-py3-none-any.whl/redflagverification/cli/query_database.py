# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

import argparse
import asyncio

from redflagverification.helpers.file_loader import FileLoader
from redflagverification.helpers.llm_helper import get_llm
from redflagverification.helpers.schema import format_schema_str
from redflagverification.stages.modular_db_query.planner import ModularDatabasePlanner


def configure(parser: argparse.ArgumentParser) -> None:
    """Configure the argument parser for this subcommand

    Args:
        parser (argparse.ArgumentParser): argument parser of subcommand
    """
    parser.add_argument("--question", "-q", type=str, help="Question about database", required=True)
    parser.add_argument(
        "--schema_file_path",
        type=str,
        help="Path of the json file that contains schema description information.",
        default="data/schema.json",
        required=False,
    )
    parser.add_argument(
        "--planner_tables_path",
        "-ptpath",
        type=str,
        help="Path of the folder where planner_tables/ folder is",
        default="data/planner_tables",
        required=False,
    )


def invoke(args: argparse.Namespace) -> None:
    """Invoke logic of command

    Args:
        src_file (str):
    """
    question = args.question
    file_loader = FileLoader(
        use_object_store=False,
        local_paths={
            "tables_schema_path": args.schema_file_path,
            "data_tables_path": args.planner_tables_path,
        },
    )
    schema_json = file_loader.get_tables_schema()
    schema_description = format_schema_str(schema_json)
    data_tables = file_loader.get_data_tables()
    llm = get_llm(ocigenai_model="openai.o3")

    if isinstance(question, str):
        planner = ModularDatabasePlanner(
            llm=llm, question=question, tables=schema_description, data_tables=data_tables
        )

    else:
        raise TypeError("question is not a string")
    result = asyncio.run(planner.run())
    print(result)
