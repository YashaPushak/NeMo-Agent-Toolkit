# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

from dataclasses import dataclass
from typing import Any, Optional

from wayflowcore._utils._templating_helpers import render_str_template


@dataclass
class RetentionPolicy:
    field_name: str
    expiration_period: int  # in days, expires after XX days


@dataclass
class UpdatePolicy:
    message_size: Optional[int] = None
    token_size: Optional[int] = None


class EmbeddingPolicy:
    def __init__(self, embedding_template: str, retrieval_template: str):
        self.embedding_template = embedding_template
        self.retrieval_template = retrieval_template

    def get_text_to_embed(self, document: dict[str, Any]) -> str:
        return render_str_template(self.embedding_template, document)

    def get_retrieved_text(self, document: dict[str, Any]) -> str:
        return render_str_template(self.retrieval_template, document)
