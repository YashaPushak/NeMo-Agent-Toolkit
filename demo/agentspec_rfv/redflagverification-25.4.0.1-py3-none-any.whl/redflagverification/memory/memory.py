# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

import json
import logging
from typing import Any, Union

from redflagverification.helpers.dbrag import get_embed_model, similarity
from redflagverification.helpers.llm_helper import get_llm
from redflagverification.memory.configuration import EmbeddingPolicy
from wayflowcore.datastore import Entity, InMemoryDatastore, OracleDatabaseDatastore
from wayflowcore.messagelist import Message, MessageList, MessageType
from wayflowcore.models import LlmModel
from wayflowcore.outputparser import JsonOutputParser
from wayflowcore.property import (
    AnyProperty,
    DictProperty,
    FloatProperty,
    IntegerProperty,
    ListProperty,
    ObjectProperty,
    StringProperty,
)
from wayflowcore.templates import PromptTemplate
from wayflowcore.tools import ServerTool

logger = logging.getLogger(__name__)

DB_STORAGE_PROMPT = """\
Given a user's technical or data-mapping question and the stepwise solution mentioned in the below conversation, generate metadata:

{% for message in __CHAT_HISTORY__ -%}
- {{ message.message_type }}: {{ message.content }}
{%- endfor %}

Use this template:
---
**original_statement**: A vague or underspecified scenario, e.g., "Increase in purchases lacks a clear reason."
**user_question**: A generalized user inquiry, e.g., "How do we determine if an increase in asset purchases is without apparent reason?"
**answer**: A generalized stepwise guide, e.g., "Check for external market events that could affect the asset, and review supporting documentation or contracts. If neither provides justification, flag as unexplained."
**metadata**:
- plan: A step-by-step outline of the recommended approach or procedure to address the scenario described. Use abstract, reusable steps applicable in similar contexts.
- embedding_hints: Example search queries or phrases that relate to the core question or logic, useful for enhancing information retrieval or semantic search.
- scope: A brief statement describing the contexts, scenarios, or systems where the guidance or logic should be applied.
- strategy: A summary of the underlying reasoning, methodology, or key approach for implementing the recommendation or rule.
- note: Additional remarks, considerations, or important caveats (such as dependencies, limitations, or reminders) relevant for applying the guidance in real-world use.
- categories: A list of descriptive tags or keywords that classify the guidance by type, purpose, or domain (e.g., Procedure, Investigation, Risk).
---
**Example Output (JSON)**:
```json
{
    "original_statement": "Increase in purchases lacks a clear reason.",
    "user_question": "How do we determine if an increase in asset purchases is without apparent reason?",
    "answer": "To assess if the increase in asset purchases has a clear rationale, investigate external market or regulatory factors that might explain the activity, and review internal contracts or policy documents for relevant justifications. If neither source provides an explanation, classify the increase as unexplained.",
    "metadata": {
        "plan": [
            "Investigate recent external factors (e.g., market news, regulatory changes, economic events) affecting the asset.",
            "Review internal contracts, agreements, investment mandates, or policy documents related to the transaction.",
            "If an external or internal justification is identified, the activity is explained; otherwise, flag as unexplained."
        ],
        "embedding_hints": [
            "How to verify unexplained increases in purchases?",
            "What explains a sudden spike in asset acquisition?"
        ],
        "scope": "This approach is suitable for any asset or transaction type where unexpected or unexplained changes require investigation. Applicable to compliance, internal audit, and anomaly detection processes.",
        "strategy": "Systematically cross-reference relevant external events and internal authorizations to explain or flag unusual activity.",
        "note": "Effectiveness depends on the availability and reliability of both internal records and external market information; insufficient context may lead to false positives or missed explanations.",
        "categories": ["Procedure", "General Investigation"]
    }
}```
"""


class TextChunkMemory:
    """
    A memory management class for storing and retrieving text chunks based on conversational data.

    This class handles the extraction of structured metadata from conversation messages,
    stores them in a datastore using embeddings for efficient similarity-based retrieval,
    and provides tools for searching and adding entries.

    Args:
        llm (LlmModel): The language model used for generating extractions.
        data_store (Union[OracleDatabaseDatastore, InMemoryDatastore]): The datastore for persisting memory entries.
        scope_id (str): The identifier for the collection or scope in the datastore.
        extraction_instruction (str): The prompt instruction used for extracting metadata from messages.
        embedding_policy (EmbeddingPolicy): Policy defining how to prepare text for embedding and retrieval.

    Note:
        Retention and update policies are not yet implemented.
    """

    def __init__(
        self,
        llm: LlmModel,
        data_store: Union[OracleDatabaseDatastore, InMemoryDatastore],
        scope_id: str,
        extraction_instruction: str,
        embedding_policy: EmbeddingPolicy,
        # Below are not implemented yet
        # retention_policy: Optional[
        #     RetentionPolicy
        # ] = None,  # If not given, default policy will be used
        # update_policy: Optional[UpdatePolicy] = None,  # If not given, default policy will be used
    ):
        self.llm = llm
        self.extraction_instruction = extraction_instruction
        self.embedding_policy = embedding_policy
        self.data_store = data_store
        self.scope_id = scope_id

    def _prepare_prompt_template(self, messages: list[Message]) -> PromptTemplate:
        schema: Entity = self.data_store.describe()[self.scope_id]

        template = PromptTemplate(
            messages=messages,
            native_structured_generation=False,
            response_format=schema,
            output_parser=JsonOutputParser(),
        )
        return template

    def _get_top_k(
        self, query: str, documents: list[dict[str, Any]], k: int, similarity_threshold: float = 0.0
    ) -> list[str]:
        embed_model = get_embed_model()
        query_embed = embed_model.embed([query])[0]

        prepared_documents = [
            self.embedding_policy.get_text_to_embed({"doc": document}) for document in documents
        ]
        embedded_docs = embed_model.embed(prepared_documents)
        docs_similarity = [
            (
                self.embedding_policy.get_retrieved_text({"doc": documents[idx]}),
                similarity(query_embed, embedded_document),  # cosine similarity
            )
            for idx, embedded_document in enumerate(embedded_docs)
        ]
        docs_similarity = sorted(docs_similarity, key=lambda x: x[1], reverse=True)
        return [data[0] for data in docs_similarity[:k] if data[1] > similarity_threshold]

    def search(self, user_question: str, top_k: int = 3, lower_limit: float = 0.0) -> list[str]:
        """
        Searches the memory for relevant text chunks based on a user question.

        This method retrieves the top-k most similar documents from the datastore
        using embedding-based similarity search.

        Args:
            user_question (str): The query string to search against.
            top_k (int, optional): The maximum number of results to return. Defaults to 3.
            lower_limit (float, optional): The similarity threshold below which results are discarded. Defaults to 0.0.

        Returns:
            list[str]: A list of retrieved text chunks, sorted by relevance.
        """
        documents = self.data_store.list(self.scope_id)
        if not documents:
            # No document available
            logger.warning("No records found in memory, nothing to retrieve")
            return []

        retrieved_context = self._get_top_k(
            query=user_question, documents=documents, k=top_k, similarity_threshold=lower_limit
        )
        return retrieved_context

    def add(self, messages: list[Message]) -> dict[str, str]:
        """
        Adds a new entry to the memory by extracting metadata from conversation messages.

        This method uses the LLM to generate structured data from the messages,
        then stores it in the datastore.

        Args:
            messages (list[Message]): The list of conversation messages to extract from.

        Returns:
            dict[str, str]: Returns the extraction prompt and extracted text.
        """
        instruction = Message(message_type=MessageType.USER, content=self.extraction_instruction)
        template = self._prepare_prompt_template([instruction])
        prompt = template.format({"__CHAT_HISTORY__": messages})
        extracted_data: str = self.llm.generate(prompt).message.content
        entry = json.loads(extracted_data)
        # save it in the datastore
        self.data_store.create(collection_name=self.scope_id, entities=entry)
        return {
            "_extraction_prompt": prompt.messages[-1].content,
            "_extracted_text": entry,
        }  # for debugging purposes

    def clean(self) -> None:
        raise NotImplementedError

    def get_search_tool(self) -> ServerTool:
        return ServerTool(
            name="search",
            description="Search in the memory and retrieve relevant information to answer the question",
            input_descriptors=[
                StringProperty(name="user_question"),
                IntegerProperty(name="top_k", default_value=3),
                FloatProperty(name="lower_limit", default_value=0.0),
            ],
            output_descriptors=[ListProperty(name="search_result", item_type=StringProperty())],
            func=self.search,
        )

    def get_add_tool(self) -> ServerTool:
        return ServerTool(
            name="add",
            description="Add a new entry to the memory",
            func=self.add,
            input_descriptors=[
                ListProperty(name="messages", item_type=AnyProperty()),
            ],
            output_descriptors=[
                DictProperty(
                    name="_extraction_info", key_type=StringProperty(), value_type=StringProperty()
                )
            ],
        )


if __name__ == "__main__":

    memory_schema = Entity(
        properties={
            "original_statement": StringProperty(),
            "user_question": StringProperty(),
            "answer": StringProperty(),
            "metadata": ObjectProperty(
                properties={
                    "plan": ListProperty(item_type=StringProperty()),
                    "embedding_hints": ListProperty(item_type=StringProperty()),
                    "scope": StringProperty(),
                    "strategy": StringProperty(),
                    "note": StringProperty(),
                    "categories": ListProperty(item_type=StringProperty()),
                }
            ),
        }
    )

    datastore = InMemoryDatastore({"fcc": memory_schema})

    existing_knowledge_file = "data/knowledge_base.json"
    with open(existing_knowledge_file, "r") as f:
        chunks = json.load(f)
    datastore.create("fcc", chunks)

    embedding_policy = EmbeddingPolicy(
        embedding_template="{{ doc.user_question }}\n{{ doc.metadata.embedding_hints|join(' ') }}",
        retrieval_template="{{ doc.user_question }}\nPlan: {{ doc.metadata.plan }}",
    )

    memory = TextChunkMemory(
        llm=get_llm(),
        data_store=datastore,
        scope_id="fcc",
        extraction_instruction=DB_STORAGE_PROMPT,
        embedding_policy=embedding_policy,
    )

    # Create a sample conversation
    conv = MessageList(
        messages=[
            Message(
                message_type=MessageType.AGENT,
                content=(
                    "Here is the original statement: International funds transfers inconsistent with transaction history"
                ),
            ),
            Message(
                message_type=MessageType.AGENT,
                content=(
                    "Question: 1. What specific criteria or patterns in the customer's prior transaction history "
                    "(e.g., frequency, amount, location, or type of transactions) would be used to determine "
                    "if an international funds transfer is inconsistent with their normal behavior, considering data "
                    "from WIRE_TRXN, CASH_TRXN, and ACCT tables for CUST_INTRL_ID = 'ADEDESD'?\n"
                    "Red flag: International funds transfers inconsistent with transaction history for customer "
                    "with CUST_INTRL_ID=ADEDESD for the period: december 2015"
                ),
            ),
            Message(
                message_type=MessageType.USER,
                content="Check whether the transaction amount has increased by more than 100 %",
            ),
        ]
    )

    # in integrated setting, we will give the add_tool to the agent
    # or have a tool execution step in a flow
    # for now we test individual methods
    add_result = memory.add(conv.get_messages())
    print(add_result)

    search_result = memory.search("How do I investigate change in behavior scenario?")
    print(search_result)
