# Copyright (C) 2024, 2025 Oracle and/or its affiliates. All rights reserved.
from typing import Any, Literal, TypedDict, Union

from typing_extensions import NotRequired


class _BaseRFVConfig(TypedDict):
    llm_master: dict[str, Any]
    llm_question: dict[str, Any]
    debug: NotRequired[bool]


class LocalRFVConfig(_BaseRFVConfig):
    use_object_store: Literal[False]
    tables_schema_path: str
    knowledge_base_path: str
    threshold_tables_path: str
    data_tables_path: str


class ObjStoreRFVConfig(_BaseRFVConfig):
    use_object_store: Literal[True]
    tables_schema_mapping: NotRequired[dict[str, str] | None]
    knowledge_base_mapping: NotRequired[dict[str, str] | None]
    threshold_tables_mapping: NotRequired[dict[str, str] | None]
    data_tables_mapping: NotRequired[dict[str, dict[str, str]] | None]
    obj_stor_connect_timeout: NotRequired[float | None]
    obj_stor_read_timeout: NotRequired[float | None]


RedFlagVerificationConfig = Union[LocalRFVConfig, ObjStoreRFVConfig]
