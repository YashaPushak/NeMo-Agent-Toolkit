# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

from abc import ABC, abstractmethod

from wayflowcore.datastore.inmemory import InMemoryDatastore
from wayflowcore.flow import Flow


class Module(ABC):
    @abstractmethod
    def execution_flow(self, memories: InMemoryDatastore) -> Flow:
        pass
