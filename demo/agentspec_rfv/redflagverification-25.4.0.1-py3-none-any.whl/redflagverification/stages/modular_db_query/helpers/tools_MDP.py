# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

import logging
import re
from typing import Optional

import pandas as pd
import sqlalchemy

from wayflowcore.datastore.inmemory import InMemoryDatastore
from wayflowcore.tools import ServerTool

logger = logging.getLogger(__name__)


def list_context(
    memories: InMemoryDatastore,
    until: Optional[str] = None,
) -> str:
    # Add Guard
    queries = memories.list("query_context_memory")
    if not queries:
        return ""

    if until:
        queries = [q for q in queries if int(q["rank"]) <= int(until)]

    steps = [f"STEP{q['rank']} AS (\n{q['content'].replace(';', '')}\n)" for q in queries]
    qcm = "WITH " + ",\n".join(steps)
    return qcm


def list_memory(memories: InMemoryDatastore) -> str:
    im = ""
    # Add Guard
    for info in memories.list("informational_memory"):
        im += f"Step {info['rank']}'s output is (\n{info['content']}\n)\n"
    return im


def update_memory_with_relevant_trxn_ids(
    memories: InMemoryDatastore, data_tables: dict[str, str]
) -> None:
    queries = memories.list("query_context_memory")
    if not queries:
        return

    def _find_TRXN_table_expr(sql_text: str) -> Optional[str]:
        pattern = r"FROM\s*\n?\s*(\w+_TRXN)"
        match = re.search(pattern, sql_text, re.IGNORECASE)
        return match.group(1) if match else None

    transactions = set()
    engine = sqlalchemy.create_engine("sqlite:///:memory:")
    for table_name, table_content in data_tables.items():
        df = pd.read_csv(pd.io.common.StringIO(table_content))
        df.to_sql(table_name, engine, if_exists="replace", index=False)

    for q in queries:
        if q["module"] == "retriever" and (table := _find_TRXN_table_expr(q["content"])):
            id_col = "BO_TRXN_INTRL_ID" if table == "BACK_OFFICE_TRXN" else "TRXN_INTRL_REF_ID"
            # id_col = "trxn_id"
            previous_queries = list_context(memories, until=q["rank"])
            query_to_execute = previous_queries + f"\nSELECT {id_col} FROM STEP{q['rank']}"

            try:
                result = pd.read_sql(query_to_execute, engine)
                transactions.update(result[id_col].tolist())
                logger.debug(f"Retrieving transaction IDs - {result[id_col]}")
            except sqlalchemy.exc.OperationalError:
                # can happen with a complex SQL query
                logger.warning(
                    "An error occured while retrieving transaction IDs - original query:\n%s\nexecuted query: %s",
                    q["content"],
                    query_to_execute,
                )

    memories.create("relevant_trxn_ids", [{"id": trxn} for trxn in transactions])


def get_informational_memory_tool(memories: InMemoryDatastore) -> ServerTool:
    def info_mem() -> str:
        return list_memory(memories)

    return ServerTool(
        name="get_informational_memory_tool",
        description="Get information memory content of each step organized in string format.",
        parameters={},
        func=info_mem,
        output={"type": "string"},
    )


def get_query_context_tool(memories: InMemoryDatastore) -> ServerTool:
    def query_con() -> str:
        return list_context(memories)

    return ServerTool(
        name="get_query_context_tool",
        description="Get query context content in step organized str format.",
        parameters={},
        func=query_con,
        output={"type": "string"},
    )


def execute_query_tool(memories: InMemoryDatastore) -> ServerTool:
    def run_query(query_extraction_io: str, data_tables: dict[str, str]) -> str:
        engine = sqlalchemy.create_engine("sqlite:///:memory:")

        for table_name, table_content in data_tables.items():
            df = pd.read_csv(pd.io.common.StringIO(table_content))
            df.to_sql(table_name, engine, if_exists="replace", index=False)

        # Problem : Generated Query was containing "WITH" sometimes and was generating errors since context sql query already had a WITH
        if "WITH" in query_extraction_io and list_context(memories) != "":
            query_to_execute = query_extraction_io.replace("WITH", "")
            query = f"{list_context(memories)},\n{query_to_execute}"
        else:
            query = f"{list_context(memories)}\n{query_extraction_io}"

        result = pd.read_sql(query, engine)

        return result.to_string()

    return ServerTool(
        name="execute_query_tool",
        description="executes a query on mock FCDM Schema and outputs in string format",
        parameters={
            "query_extraction_io": {
                "description": "Query to be executed",
                "type": "string",
                "default": "",
            },
            "data_tables": {
                "description": "Tables with needed data for transactions and accounts.",
                "type": "object",
                "default": "",
            },
        },
        func=run_query,
        output={"type": "string"},
    )


def get_update_informational_memory_tool(memories: InMemoryDatastore) -> ServerTool:
    def update_informational_memory(
        rank: str,
        content: str,
    ) -> str:
        memories.create("informational_memory", {"rank": rank, "content": content})
        return "Done"

    return ServerTool(
        name="update_informational_memory",
        description="Update informational memory",
        parameters={
            "rank": {"description": "Rank of the step", "type": "string", "default": "0"},
            "content": {"description": "element content", "type": "string", "default": ""},
        },
        func=update_informational_memory,
        output={"type": "string", "default": "nothing"},
    )


def get_update_query_context_memory_tool(memories: InMemoryDatastore) -> ServerTool:
    def update_query_context_memory(
        rank: str,
        content: str,
        module: str,
    ) -> None:
        memories.create(
            "query_context_memory", {"rank": rank, "content": content, "module": module}
        )

    return ServerTool(
        name="update_query_context_memory",
        description="Update context memory",
        parameters={
            "rank": {"description": "Rank of the step", "type": "string", "default": "0"},
            "content": {"description": "element content", "type": "string", "default": ""},
            "module": {
                "description": "either retriever or informer",
                "type": "string",
                "default": "",
            },
        },
        func=update_query_context_memory,
        output={"type": "string", "default": "nothing"},
    )
