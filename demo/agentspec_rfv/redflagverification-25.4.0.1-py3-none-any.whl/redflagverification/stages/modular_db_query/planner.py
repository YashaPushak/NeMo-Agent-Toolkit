# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

from typing import Any, Dict

from redflagverification.helpers.openagentspec import get_regex_extraction_step
from redflagverification.stages.constants import (
    BRANCHING_STEP,
    DATA_TABLES,
    EXECUTOR_EXECUTION_STEP,
    INFORMER_EXECUTION_STEP,
    LLM_PLAN_GENERATION_STEP,
    MODULE_EXTRACTION_STEP,
    OUTPUT_STEP,
    PLAN_EXECUTION_STEP,
    PLAN_EXTRACTION_STEP,
    RETRIEVER_EXECUTION_STEP,
    START_STEP,
    STATEMENT_IO,
    STEP_IO,
    STEP_VALUE_EXTRACTION_IO,
    STEP_VALUE_EXTRACTION_STEP,
    TABLES_IO,
    TASK_EXTRACTION_IO,
    TASK_EXTRACTION_STEP,
)
from redflagverification.stages.modular_db_query.helpers.module import Module
from redflagverification.stages.modular_db_query.helpers.tools_MDP import (
    get_informational_memory_tool,
    update_memory_with_relevant_trxn_ids,
)
from redflagverification.stages.modular_db_query.modules.executor import Executor
from redflagverification.stages.modular_db_query.modules.informer import Informer
from redflagverification.stages.modular_db_query.modules.retriever import Retriever
from redflagverification.tracing.exporters import InMemoryExporter
from redflagverification.tracing.rfvtrace import RFVTrace, debug_enabled
from redflagverification.tracing.spans import PlannerSpan
from wayflowcore.controlconnection import ControlFlowEdge
from wayflowcore.dataconnection import DataFlowEdge
from wayflowcore.datastore import Entity
from wayflowcore.datastore.inmemory import InMemoryDatastore
from wayflowcore.flow import Flow
from wayflowcore.models.llmmodel import LlmModel
from wayflowcore.property import DictProperty, ListProperty, StringProperty
from wayflowcore.steps import (
    BranchingStep,
    FlowExecutionStep,
    MapStep,
    PromptExecutionStep,
    RegexExtractionStep,
    StartStep,
    ToolExecutionStep,
)
from wayflowcore.tracing.spanprocessor import SimpleSpanProcessor

PLANNER_PROMPT = """\
You are a **policy model**. Your job is to decide which modules to use, and in what order, to **answer a specific question** using a set of available modules.
You must return a **sequence of steps**. Each step should:
- Use **one module**
- Clearly describe what it does
- Mention which **previous step(s)' output** it uses as input
---

- Rules:
- Only focus on **answering the question**, nothing else
- Use the **minimum number of tables** possible
- Keep each step **simple** and **granular** — each module should do just one clear task
---

- Available Modules:
- **Retriever**
Use this module to retrieve and process data from predefined tables. It's responsible for all table-related operations like fetching, filtering, merging, or aggregating — **done in one simple SQL query**.
The Retriever can take multiple tables as input, but must return only **one table** as output. Only the Retriever can directly interact with tables.
- **Informer**
The Informer acts as the bridge between the tables and the Executor. It takes the output from the Retriever and extracts the specific information needed — such as length, min/max values, specific entries, or any summarization.
It transforms structured table data into plain, readable text or simple values. If any information needs to be pulled or summarized from a table, **the Informer must handle it**, not the Executor.
- **Executor**
This module performs logical decision making and thinking, it should be provided with the final data and it should use the data to make a decision. Unless it's the final answer, the executor shouldn't be provided with a table that can contain a lot of lines (conetxt window).
---

- In-context example
**Question to answer:**
Are there more than 4 international transactions transiting through the account(s) of the `CUST_INTRL_ID = ADACA342432` during the month of `04/07/2016`?
**Your Output's format:**
Thoughts : thoughts here
Plan :
##[1. Retriever: Fetches accounts of the customer with CUST_INTRL_ID = 'ADACA342432'. %%INPUT:[]]##
##[2. Retriever: Fetches transactions of those accounts from WIRE_TRXN. %%INPUT:[STEP1]]##
##[3. Informer: Gets the number of international transactions using FRGN_TRXN_FL. %%INPUT:[STEP2]]##
##[4. Executor: Checks if the number is greater than 4. %%INPUT:[STEP3]]##
(like in the example, each step should be between ##[...]##, your tasks shouldn't include SQL queries they should be natural language tasks.)
(Each step should be in one line, natural language, using table names if helpful, but do not instruct on details such as filtering or joining.)
---

- Available Tables:
{{tables_io}}
---

- Question to Answer:
{{statement_io}}
"""


class ModularDatabasePlanner:
    def __init__(
        self,
        llm: LlmModel,
        question: str,
        tables: str,
        data_tables: dict[str, str],
        red_flag: str = "",
        scenario: str = "",
        is_undetermined: bool = False,
        clarification_questions: list[str] = [],
    ) -> None:

        query = Entity(
            description="history of generated queries during the plan execution",
            properties={
                "rank": StringProperty(),
                "module": StringProperty(),
                "content": StringProperty(default_value=""),
            },
        )

        information = Entity(
            description="history of generated informations during the plan execution",
            properties={
                "rank": StringProperty(),
                "content": StringProperty(default_value=""),
            },
        )

        transaction = Entity(
            description="to keep track of relevant transactions",
            properties={
                "id": StringProperty(),
            },
        )

        self.llm = llm
        self.question = question
        self.tables = tables
        self.data_tables = data_tables
        self.memories = InMemoryDatastore(
            {
                "query_context_memory": query,
                "informational_memory": information,
                "relevant_trxn_ids": transaction,
            },
        )
        self.modules: Dict[str, Module] = {
            "Retriever": Retriever(llm=llm, tables=tables),
            "Informer": Informer(llm=llm, tables=tables),
            "Executor": Executor(llm=llm, tables=tables),
        }

        self.red_flag = red_flag
        self.scenario = scenario
        self.is_undetermined = is_undetermined
        self.clarification_questions = clarification_questions

    def get_step_execution_flow(self) -> Flow:

        start_step = StartStep(
            name=START_STEP,
            input_descriptors=[
                StringProperty(name=STEP_IO, description="Task Definition"),
                StringProperty(name=TABLES_IO, description="Tables"),
                DictProperty(
                    name=DATA_TABLES,
                    description="Tables with content about transcations, accounts etc.",
                ),
            ],
        )

        step_value_extraction_step = get_regex_extraction_step(
            name=STEP_VALUE_EXTRACTION_STEP,
            regex_pattern=r"^\d+",
        )

        module_extraction_step = get_regex_extraction_step(
            name=MODULE_EXTRACTION_STEP,
            regex_pattern=r"^\d+\.\s*(\w+)",
        )

        task_extraction_step = get_regex_extraction_step(
            name=TASK_EXTRACTION_STEP,
            regex_pattern=r"^\d+\.\s*\w+:\s*((?:.|\r?\n)*?)%%INPUT:",
        )

        branching_step = BranchingStep(
            name=BRANCHING_STEP,
            branch_name_mapping={
                "Retriever": "retriever_execution",
                "Informer": "informer_execution",
                "Executor": "execution",
            },
            input_descriptors=[
                StringProperty(name=BranchingStep.NEXT_BRANCH_NAME),
            ],
        )

        retriever = self.modules["Retriever"]

        retriever_execution_step = FlowExecutionStep(
            name=RETRIEVER_EXECUTION_STEP,
            flow=retriever.execution_flow(self.memories),
            input_descriptors=[
                StringProperty(name=STEP_VALUE_EXTRACTION_IO),
                StringProperty(name=TASK_EXTRACTION_IO),
                StringProperty(name=TABLES_IO),
            ],
        )

        informer = self.modules["Informer"]

        informer_execution_step = FlowExecutionStep(
            name=INFORMER_EXECUTION_STEP,
            flow=informer.execution_flow(self.memories),
            input_descriptors=[
                StringProperty(name=STEP_VALUE_EXTRACTION_IO),
                StringProperty(name=TASK_EXTRACTION_IO),
                StringProperty(name=TABLES_IO),
                DictProperty(name=DATA_TABLES),
            ],
        )

        executor = self.modules["Executor"]

        executor_execution_step = FlowExecutionStep(
            name=EXECUTOR_EXECUTION_STEP,
            flow=executor.execution_flow(self.memories),
            input_descriptors=[
                StringProperty(name=STEP_VALUE_EXTRACTION_IO),
                StringProperty(name=TASK_EXTRACTION_IO),
                StringProperty(name=TABLES_IO),
            ],
        )

        flow = Flow(
            begin_step=start_step,
            control_flow_edges=[
                ControlFlowEdge(
                    source_step=start_step, destination_step=step_value_extraction_step
                ),
                ControlFlowEdge(
                    source_step=step_value_extraction_step, destination_step=module_extraction_step
                ),
                ControlFlowEdge(
                    source_step=module_extraction_step, destination_step=task_extraction_step
                ),
                ControlFlowEdge(source_step=task_extraction_step, destination_step=branching_step),
                ControlFlowEdge(
                    source_step=branching_step,
                    destination_step=retriever_execution_step,
                    source_branch="retriever_execution",
                ),
                ControlFlowEdge(
                    source_step=branching_step,
                    destination_step=informer_execution_step,
                    source_branch="informer_execution",
                ),
                ControlFlowEdge(
                    source_step=branching_step,
                    destination_step=executor_execution_step,
                    source_branch="execution",
                ),
                ControlFlowEdge(
                    source_step=branching_step,
                    destination_step=retriever_execution_step,
                    source_branch=BranchingStep.BRANCH_DEFAULT,
                ),
                ControlFlowEdge(source_step=retriever_execution_step, destination_step=None),
                ControlFlowEdge(source_step=informer_execution_step, destination_step=None),
                ControlFlowEdge(source_step=executor_execution_step, destination_step=None),
            ],
            data_flow_edges=[
                DataFlowEdge(
                    start_step, STEP_IO, step_value_extraction_step, RegexExtractionStep.TEXT
                ),
                DataFlowEdge(start_step, STEP_IO, module_extraction_step, RegexExtractionStep.TEXT),
                DataFlowEdge(start_step, STEP_IO, task_extraction_step, RegexExtractionStep.TEXT),
                DataFlowEdge(
                    module_extraction_step,
                    RegexExtractionStep.OUTPUT,
                    branching_step,
                    BranchingStep.NEXT_BRANCH_NAME,
                ),
                DataFlowEdge(
                    step_value_extraction_step,
                    RegexExtractionStep.OUTPUT,
                    retriever_execution_step,
                    STEP_VALUE_EXTRACTION_IO,
                ),
                DataFlowEdge(
                    task_extraction_step,
                    RegexExtractionStep.OUTPUT,
                    retriever_execution_step,
                    TASK_EXTRACTION_IO,
                ),
                DataFlowEdge(start_step, TABLES_IO, retriever_execution_step, TABLES_IO),
                DataFlowEdge(
                    step_value_extraction_step,
                    RegexExtractionStep.OUTPUT,
                    informer_execution_step,
                    STEP_VALUE_EXTRACTION_IO,
                ),
                DataFlowEdge(
                    task_extraction_step,
                    RegexExtractionStep.OUTPUT,
                    informer_execution_step,
                    TASK_EXTRACTION_IO,
                ),
                DataFlowEdge(start_step, TABLES_IO, informer_execution_step, TABLES_IO),
                DataFlowEdge(start_step, DATA_TABLES, informer_execution_step, DATA_TABLES),
                DataFlowEdge(
                    step_value_extraction_step,
                    RegexExtractionStep.OUTPUT,
                    executor_execution_step,
                    STEP_VALUE_EXTRACTION_IO,
                ),
                DataFlowEdge(
                    task_extraction_step,
                    RegexExtractionStep.OUTPUT,
                    executor_execution_step,
                    TASK_EXTRACTION_IO,
                ),
                DataFlowEdge(start_step, TABLES_IO, executor_execution_step, TABLES_IO),
            ],
        )
        return flow

    def moodular_db_flow(self) -> Flow:

        start_step = StartStep(
            name=START_STEP,
            input_descriptors=[
                StringProperty(name=TABLES_IO, description="Task Definition"),
                StringProperty(name=STATEMENT_IO, description="Q"),
                DictProperty(
                    name=DATA_TABLES,
                    description="Tables with content about transcations, accounts etc.",
                ),
            ],
        )

        llm_plan_generation_step = PromptExecutionStep(
            name=LLM_PLAN_GENERATION_STEP,
            prompt_template=PLANNER_PROMPT,
            llm=self.llm,
            input_descriptors=[
                StringProperty(name=TABLES_IO, description="Tables Schema"),
                StringProperty(name=STATEMENT_IO, description="Red Flag"),
            ],
            output_descriptors=[
                StringProperty(name=PromptExecutionStep.OUTPUT, description="LLM's raw generation"),
            ],
        )

        plan_extraction_step = get_regex_extraction_step(
            name=PLAN_EXTRACTION_STEP,
            regex_pattern=r"##\[((?:.|\r?\n)*?)\]##",
            return_first_match_only=False,
        )

        plan_execution_step = MapStep(
            name=PLAN_EXECUTION_STEP,
            flow=self.get_step_execution_flow(),
            unpack_input={STEP_IO: "."},
            input_descriptors=[
                StringProperty(name=TABLES_IO, description="Tables Schema"),
                ListProperty(name=MapStep.ITERATED_INPUT, description="iterated_input"),
                DictProperty(
                    name=DATA_TABLES,
                    description="Tables with content about transactions, accounts etc.",
                ),
            ],
        )

        output_step = ToolExecutionStep(
            name=OUTPUT_STEP,
            tool=get_informational_memory_tool(self.memories),
            output_descriptors=[
                StringProperty(name=ToolExecutionStep.TOOL_OUTPUT, description="output of tool"),
            ],
        )
        flow = Flow(
            begin_step=start_step,
            control_flow_edges=[
                ControlFlowEdge(source_step=start_step, destination_step=llm_plan_generation_step),
                ControlFlowEdge(
                    source_step=llm_plan_generation_step, destination_step=plan_extraction_step
                ),
                ControlFlowEdge(
                    source_step=plan_extraction_step, destination_step=plan_execution_step
                ),
                ControlFlowEdge(source_step=plan_execution_step, destination_step=output_step),
                ControlFlowEdge(source_step=output_step, destination_step=None),
            ],
            data_flow_edges=[
                DataFlowEdge(start_step, TABLES_IO, llm_plan_generation_step, TABLES_IO),
                DataFlowEdge(start_step, TABLES_IO, plan_execution_step, TABLES_IO),
                DataFlowEdge(start_step, DATA_TABLES, plan_execution_step, DATA_TABLES),
                DataFlowEdge(start_step, STATEMENT_IO, llm_plan_generation_step, STATEMENT_IO),
                DataFlowEdge(
                    llm_plan_generation_step,
                    PromptExecutionStep.OUTPUT,
                    plan_extraction_step,
                    RegexExtractionStep.TEXT,
                ),
                DataFlowEdge(
                    plan_extraction_step,
                    RegexExtractionStep.OUTPUT,
                    plan_execution_step,
                    MapStep.ITERATED_INPUT,
                ),
            ],
        )
        return flow

    async def _run_planner_with_span(
        self,
        flow: Flow,
        span_exporter: InMemoryExporter,
    ) -> dict[str, Any]:
        """
        Execute the planner flow within a PlannerSpan and record tracing data.

        If the planner crashes, the span is still properly closed and a partial
        trace is exported and attached to the raised exception as 'partial_trace'
        """
        with PlannerSpan() as span:
            try:
                conversation = flow.start_conversation(
                    inputs={
                        TABLES_IO: self.tables,
                        STATEMENT_IO: self.question,
                        DATA_TABLES: self.data_tables,
                    }
                )
                status = await conversation.execute_async()
                span.record_end_span_event(span_exporter.span_list)
                trace: dict[str, Any] = span._get_slim_trace()

            except Exception as e:
                try:
                    span.record_end_span_event(span_exporter.span_list)
                    partial = span._get_slim_trace()
                except Exception as pt_exc:
                    new_exc = RuntimeError(
                        f"Planner run failed during execution: {e!r}; additionally failed to build partial trace: {pt_exc!r}"
                    )
                    raise new_exc from e
                new_exc = RuntimeError(f"Planner run failed during execution: {e!r}")
                setattr(new_exc, "partial_trace", partial)
                raise new_exc from e

        update_memory_with_relevant_trxn_ids(self.memories, self.data_tables)
        trace["relevant_transactions"] = self.memories.list("relevant_trxn_ids")
        return trace

    async def run(self, span_exporter: InMemoryExporter | None = None) -> dict[str, Any]:
        """
        Run the Modular Database Planner with tracing and return a slim, planner-level trace.

        Behavior:
        - Builds and executes the modular DB planner flow (Retriever, Informer, Executor).
        - If span_exporter is provided, uses the caller-managed Trace/exporter; otherwise creates a local Trace.
        - Executes the planner within a PlannerSpan, exporting span events to the provided or local exporter.
        - In debug mode, includes raw LLM outputs in llm_call_stats.
        - On error, ensures the span is closed and a partial trace is still exported, which is attached to the raised exception.

        Args:
            span_exporter (InMemoryExporter | None): Optional exporter to collect span events.
                - If None, a local InMemoryExporter is created and managed internally.
                - If provided, no new Trace is created; the caller is responsible for the outer Trace context.

        Returns:
            dict[str, Any]: Slim trace dictionary including:
                - plan: list[str]
                - steps_execution: list[dict[str, Any]] with keys: module, step, output
                - llm_call_stats: list[dict[str, Any]] per LLM call
                - total_stats: dict[str, Any] aggregated by model_id

        Raises:
            RuntimeError: If the planner fails during execution (with partial_trace attached)
        """
        flow = self.moodular_db_flow()
        trace: dict[str, Any] = {}

        if span_exporter is None:
            local_exporter = InMemoryExporter()
            with RFVTrace(
                debug=debug_enabled(), span_processors=[SimpleSpanProcessor(local_exporter)]
            ):
                trace = await self._run_planner_with_span(flow=flow, span_exporter=local_exporter)
        else:
            trace = await self._run_planner_with_span(flow=flow, span_exporter=span_exporter)

        return trace


def parse_planner_trace(trace: dict[str, Any]) -> tuple[str, list[dict[str, str]]]:
    steps = trace.get("steps_execution") or []
    if not steps:
        raise ValueError("Planner trace doesn't contain steps_execution")

    last_step_output = steps[-1].get("output")

    query_context_memory = []
    for idx, entry in enumerate(steps, start=1):
        if entry.get("module") == "Executor":
            continue
        output = entry.get("output")
        query_context_memory.append({"content": output, "rank": str(idx)})

    return last_step_output, query_context_memory
