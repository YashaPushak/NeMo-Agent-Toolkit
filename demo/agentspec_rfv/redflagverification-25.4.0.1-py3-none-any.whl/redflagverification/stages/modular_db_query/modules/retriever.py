# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

from redflagverification.helpers.openagentspec import (
    get_regex_extraction_step,
    render_extra_requirements,
    render_previous_step_queries,
)
from redflagverification.stages.constants import (
    EXTRA_REQUIREMENTS_IO,
    EXTRA_REQUIREMENTS_RENDERING_STEP,
    LLM_QUERY_GENERATION_STEP,
    QUERY_CONTEXT_RENDERING_STEP,
    QUERY_CONTEXT_UPDATE_STEP,
    QUERY_EXTRACTION_STEP,
    RENDERED_PREVIOUS_QUERIES,
    RETRIEVE_CONTEXT_IO,
    RETRIEVE_CONTEXT_STEP,
    START_STEP,
    STEP_VALUE_EXTRACTION_IO,
    TABLES_IO,
    TASK_EXTRACTION_IO,
)
from redflagverification.stages.modular_db_query.helpers.module import Module
from redflagverification.stages.modular_db_query.helpers.tools_MDP import (
    get_query_context_tool,
    get_update_query_context_memory_tool,
)
from wayflowcore.controlconnection import ControlFlowEdge
from wayflowcore.dataconnection import DataFlowEdge
from wayflowcore.datastore.inmemory import InMemoryDatastore
from wayflowcore.flow import Flow
from wayflowcore.models.llmmodel import LlmModel
from wayflowcore.property import StringProperty
from wayflowcore.steps import PromptExecutionStep, RegexExtractionStep, StartStep, ToolExecutionStep
from wayflowcore.tools import ServerTool

RETRIEVER_PROPMT = """\
You are a Data Retriever and you are required to execute a single Retrieveing step of a plan, your \
output should be a single table.

You have these available tables :
{{ tables_io }}

{{ rendered_previous_queries }}

And you need to realise this query using SQLite queries : {{ task_extraction_io }}

Requirements:
- ONLY select the explicitly required columns – do NOT use SELECT *.
- When retrieving transactions, ALWAYS include the transaction ID column.
- Only use the available columns listed for each table—assume no others exist.
- Use the minimal number of tables necessary.
{{ extra_requirements_io }}
- Return only the query—place it directly between the triple backticks below.
- Do NOT use the word 'sql' before or after the query inside the backticks.
- Do NOT use bindings in any form.

Output format:
```
(your query here)
```
"""


class Retriever(Module):
    """SQL retrieving module"""

    def __init__(self, llm: LlmModel, tables: str) -> None:

        self.llm = llm
        self.tables = tables

    def execution_flow(self, memories: InMemoryDatastore) -> Flow:

        start_step = StartStep(
            name=START_STEP,
            input_descriptors=[
                StringProperty(name=STEP_VALUE_EXTRACTION_IO, description="Rank of Step"),
                StringProperty(name=TASK_EXTRACTION_IO, description="Task Definition"),
                StringProperty(name=TABLES_IO, description="tables"),
            ],
        )

        retrieve_context_step = ToolExecutionStep(
            name=RETRIEVE_CONTEXT_STEP,
            tool=get_query_context_tool(memories),
            output_descriptors=[
                StringProperty(name=ToolExecutionStep.TOOL_OUTPUT),
            ],
        )

        previous_queries_rendering_step = ToolExecutionStep(
            name=QUERY_CONTEXT_RENDERING_STEP,
            tool=ServerTool(
                name="render_previous_step_queries",
                description="Rendering previous step queries to put in the prompt",
                input_descriptors=[
                    StringProperty(name=STEP_VALUE_EXTRACTION_IO),
                    StringProperty(name=RETRIEVE_CONTEXT_IO),
                ],
                output_descriptors=[
                    StringProperty(name=RENDERED_PREVIOUS_QUERIES),
                ],
                func=render_previous_step_queries,
            ),
        )

        extra_requirements_rendering_step = ToolExecutionStep(
            name=EXTRA_REQUIREMENTS_RENDERING_STEP,
            tool=ServerTool(
                name="render_extra_requirements",
                description="Rendering extra requirements to put in the prompt",
                input_descriptors=[
                    StringProperty(name=STEP_VALUE_EXTRACTION_IO),
                ],
                output_descriptors=[
                    StringProperty(name=EXTRA_REQUIREMENTS_IO),
                ],
                func=render_extra_requirements,
            ),
        )

        llm_query_generation_step = PromptExecutionStep(
            name=LLM_QUERY_GENERATION_STEP,
            prompt_template=RETRIEVER_PROPMT,
            llm=self.llm,
            input_descriptors=[
                StringProperty(name=TASK_EXTRACTION_IO),
                StringProperty(name=TABLES_IO),
            ],
            output_descriptors=[
                StringProperty(name=PromptExecutionStep.OUTPUT),
            ],
        )

        query_extraction_step = get_regex_extraction_step(
            name=QUERY_EXTRACTION_STEP,
            regex_pattern=r"```(?:sql)?\s*([\s\S]*?)```",
        )

        query_context_update_step = ToolExecutionStep(
            name=QUERY_CONTEXT_UPDATE_STEP,
            tool=get_update_query_context_memory_tool(memories),
            input_descriptors=[
                StringProperty(name="rank"),
                StringProperty(name="content"),
                StringProperty(name="module", default_value="retriever"),
            ],
            output_descriptors=[
                StringProperty(name=ToolExecutionStep.TOOL_OUTPUT, default_value="Done"),
            ],
        )

        flow = Flow(
            begin_step=start_step,
            control_flow_edges=[
                ControlFlowEdge(source_step=start_step, destination_step=retrieve_context_step),
                ControlFlowEdge(
                    source_step=retrieve_context_step,
                    destination_step=previous_queries_rendering_step,
                ),
                ControlFlowEdge(
                    source_step=previous_queries_rendering_step,
                    destination_step=extra_requirements_rendering_step,
                ),
                ControlFlowEdge(
                    source_step=extra_requirements_rendering_step,
                    destination_step=llm_query_generation_step,
                ),
                ControlFlowEdge(
                    source_step=llm_query_generation_step, destination_step=query_extraction_step
                ),
                ControlFlowEdge(
                    source_step=query_extraction_step, destination_step=query_context_update_step
                ),
                ControlFlowEdge(source_step=query_context_update_step, destination_step=None),
            ],
            data_flow_edges=[
                DataFlowEdge(
                    start_step,
                    STEP_VALUE_EXTRACTION_IO,
                    previous_queries_rendering_step,
                    STEP_VALUE_EXTRACTION_IO,
                ),
                DataFlowEdge(
                    start_step,
                    STEP_VALUE_EXTRACTION_IO,
                    extra_requirements_rendering_step,
                    STEP_VALUE_EXTRACTION_IO,
                ),
                DataFlowEdge(
                    extra_requirements_rendering_step,
                    EXTRA_REQUIREMENTS_IO,
                    llm_query_generation_step,
                    EXTRA_REQUIREMENTS_IO,
                ),
                DataFlowEdge(
                    start_step, TASK_EXTRACTION_IO, llm_query_generation_step, TASK_EXTRACTION_IO
                ),
                DataFlowEdge(start_step, TABLES_IO, llm_query_generation_step, TABLES_IO),
                DataFlowEdge(
                    retrieve_context_step,
                    ToolExecutionStep.TOOL_OUTPUT,
                    previous_queries_rendering_step,
                    RETRIEVE_CONTEXT_IO,
                ),
                DataFlowEdge(
                    previous_queries_rendering_step,
                    RENDERED_PREVIOUS_QUERIES,
                    llm_query_generation_step,
                    RENDERED_PREVIOUS_QUERIES,
                ),
                DataFlowEdge(
                    llm_query_generation_step,
                    PromptExecutionStep.OUTPUT,
                    query_extraction_step,
                    RegexExtractionStep.TEXT,
                ),
                DataFlowEdge(
                    query_extraction_step,
                    RegexExtractionStep.OUTPUT,
                    query_context_update_step,
                    "content",
                ),
                DataFlowEdge(
                    start_step, STEP_VALUE_EXTRACTION_IO, query_context_update_step, "rank"
                ),
            ],
        )
        return flow
