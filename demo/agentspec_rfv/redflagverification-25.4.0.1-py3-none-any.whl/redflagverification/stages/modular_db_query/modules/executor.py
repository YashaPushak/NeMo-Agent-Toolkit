# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

from redflagverification.stages.constants import (
    INFORMATIONAL_MEMORY_IO,
    INFORMATIONAL_MEMORY_UPDATE_STEP,
    LLM_QUERY_GENERATION_STEP,
    RETRIEVE_INFO_STEP,
    START_STEP,
    STEP_VALUE_EXTRACTION_IO,
    TABLES_IO,
    TASK_EXTRACTION_IO,
)
from redflagverification.stages.modular_db_query.helpers.module import Module
from redflagverification.stages.modular_db_query.helpers.tools_MDP import (
    get_informational_memory_tool,
    get_update_informational_memory_tool,
)
from wayflowcore.controlconnection import ControlFlowEdge
from wayflowcore.dataconnection import DataFlowEdge
from wayflowcore.datastore.inmemory import InMemoryDatastore
from wayflowcore.flow import Flow
from wayflowcore.models.llmmodel import LlmModel
from wayflowcore.property import StringProperty
from wayflowcore.steps import PromptExecutionStep, StartStep, ToolExecutionStep

EXECUTOR_PROMPT = """\
Using the following information and only the following information : {{informational_memory_io}}, execute the following step : {{task_extraction_io}}
Be concise and brief in your answer, give only what was asked.
Remember if this is the final answer, finish with:
- <final answer: $your_answer$> with $your_answer$ being either Yes or No.
- <reason: $your_reason$> with $your_reason$ being a concise, one sentence summary of the investigation that backs up the final answer.
"""


class Executor(Module):
    """Reasoning Module that uses Retrived info to make decisions"""

    def __init__(self, llm: LlmModel, tables: str) -> None:

        self.llm = llm
        self.tables = tables

    def execution_flow(self, memories: InMemoryDatastore) -> Flow:

        start_step = StartStep(
            name=START_STEP,
            input_descriptors=[
                StringProperty(name=STEP_VALUE_EXTRACTION_IO, description="Rank of Step"),
                StringProperty(name=TASK_EXTRACTION_IO, description="Task Definition"),
                StringProperty(name=TABLES_IO, description="tables"),
            ],
        )
        retrieve_info_step = ToolExecutionStep(
            name=RETRIEVE_INFO_STEP,
            tool=get_informational_memory_tool(memories),
            output_descriptors=[
                StringProperty(name=ToolExecutionStep.TOOL_OUTPUT),
            ],
        )

        llm_query_generation_step = PromptExecutionStep(
            name=LLM_QUERY_GENERATION_STEP,
            prompt_template=EXECUTOR_PROMPT,
            llm=self.llm,
            output_descriptors=[
                StringProperty(name=PromptExecutionStep.OUTPUT),
            ],
        )

        informational_memory_update_step = ToolExecutionStep(
            name=INFORMATIONAL_MEMORY_UPDATE_STEP,
            tool=get_update_informational_memory_tool(memories),
            input_descriptors=[
                StringProperty(name="rank"),
                StringProperty(name="content"),
            ],
            output_descriptors=[
                StringProperty(name=ToolExecutionStep.TOOL_OUTPUT),
            ],
        )

        flow = Flow(
            begin_step=start_step,
            control_flow_edges=[
                ControlFlowEdge(source_step=start_step, destination_step=retrieve_info_step),
                ControlFlowEdge(
                    source_step=retrieve_info_step, destination_step=llm_query_generation_step
                ),
                ControlFlowEdge(
                    source_step=llm_query_generation_step,
                    destination_step=informational_memory_update_step,
                ),
                ControlFlowEdge(
                    source_step=informational_memory_update_step, destination_step=None
                ),
            ],
            data_flow_edges=[
                DataFlowEdge(
                    retrieve_info_step,
                    ToolExecutionStep.TOOL_OUTPUT,
                    llm_query_generation_step,
                    INFORMATIONAL_MEMORY_IO,
                ),
                DataFlowEdge(
                    start_step, TASK_EXTRACTION_IO, llm_query_generation_step, TASK_EXTRACTION_IO
                ),
                DataFlowEdge(
                    llm_query_generation_step,
                    PromptExecutionStep.OUTPUT,
                    informational_memory_update_step,
                    "content",
                ),
                DataFlowEdge(
                    start_step, STEP_VALUE_EXTRACTION_IO, informational_memory_update_step, "rank"
                ),
            ],
        )
        return flow
