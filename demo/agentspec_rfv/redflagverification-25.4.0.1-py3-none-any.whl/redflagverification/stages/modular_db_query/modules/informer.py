# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

from redflagverification.helpers.openagentspec import (
    get_regex_extraction_step,
    render_extra_requirements,
    render_previous_step_queries,
)
from redflagverification.stages.constants import (
    DATA_TABLES,
    EXTRA_REQUIREMENTS_IO,
    EXTRA_REQUIREMENTS_RENDERING_STEP,
    INFORMATIONAL_MEMORY_UPDATE_STEP,
    LLM_QUERY_GENERATION_STEP,
    QUERY_CONTEXT_RENDERING_STEP,
    QUERY_CONTEXT_UPDATE_STEP,
    QUERY_EXECUTION_STEP,
    QUERY_EXTRACTION_IO,
    QUERY_EXTRACTION_STEP,
    RENDERED_PREVIOUS_QUERIES,
    RETRIEVE_CONTEXT_IO,
    RETRIEVE_CONTEXT_STEP,
    START_STEP,
    STEP_VALUE_EXTRACTION_IO,
    TABLES_IO,
    TASK_EXTRACTION_IO,
)
from redflagverification.stages.modular_db_query.helpers.module import Module
from redflagverification.stages.modular_db_query.helpers.tools_MDP import (
    execute_query_tool,
    get_query_context_tool,
    get_update_informational_memory_tool,
    get_update_query_context_memory_tool,
)
from wayflowcore.controlconnection import ControlFlowEdge
from wayflowcore.dataconnection import DataFlowEdge
from wayflowcore.datastore.inmemory import InMemoryDatastore
from wayflowcore.flow import Flow
from wayflowcore.models.llmmodel import LlmModel
from wayflowcore.property import DictProperty, StringProperty
from wayflowcore.steps import PromptExecutionStep, RegexExtractionStep, StartStep, ToolExecutionStep
from wayflowcore.tools import ServerTool

INFORMER_PROMPT = """\
You are an Informer, your goal is to receive a table as input and retrieve data from it. For e.g, \
get values from it like the length, the max-min, values, informations, etc...

You have these available tables :
{{ tables_io }}

{{ rendered_previous_queries }}

And you need to realise this query using SQLite queries : {{ task_extraction_io }}

Requirements:
- Use only a SELECT statement for your answer—do not use or generate any WITH clauses or Common \
Table Expressions (CTEs) for previous queries or prior-step results in your output.
- You may refer to the results of previous queries provided (such as tables or temporary views \
made available from prior steps), but do not redefine these queries or include their logic in your \
output. Assume those previous step results exist and are available for use as tables.
- You may use WITH clauses or CTEs in your query if needed, but only for tables available in the \
current step (not for prior-step queries).
- ONLY select the explicitly required columns—do NOT use SELECT *.
- Only use the available columns listed for each table—assume no others exist.
- Use the minimal number of tables necessary.
{{ extra_requirements_io }}
- Return only the query—place it directly between the triple backticks below.
- Do NOT use the word 'sql' before or after the query inside the backticks.
- Do NOT use bindings in any form.

Output format:
```
(your query here)
```
"""


class Informer(Module):
    """Bridge Module that transforms DB information to textual information for the Executor"""

    def __init__(self, llm: LlmModel, tables: str) -> None:

        self.llm = llm
        self.tables = tables

    def execution_flow(self, memories: InMemoryDatastore) -> Flow:

        start_step = StartStep(
            name=START_STEP,
            input_descriptors=[
                StringProperty(name=STEP_VALUE_EXTRACTION_IO, description="Rank of Step"),
                StringProperty(name=TASK_EXTRACTION_IO, description="Task Definition"),
                StringProperty(name=TABLES_IO, description="Tables schema"),
                DictProperty(
                    name=DATA_TABLES,
                    description="Tables with content about transcations, accounts etc.",
                ),
            ],
        )
        retrieve_context_step = ToolExecutionStep(
            name=RETRIEVE_CONTEXT_STEP,
            tool=get_query_context_tool(memories),
            output_descriptors=[
                StringProperty(name=ToolExecutionStep.TOOL_OUTPUT),
            ],
        )

        previous_queries_rendering_step = ToolExecutionStep(
            name=QUERY_CONTEXT_RENDERING_STEP,
            tool=ServerTool(
                name="render_previous_step_queries",
                description="Rendering previous step queries to put in the prompt",
                input_descriptors=[
                    StringProperty(name=STEP_VALUE_EXTRACTION_IO),
                    StringProperty(name=RETRIEVE_CONTEXT_IO),
                ],
                output_descriptors=[
                    StringProperty(name=RENDERED_PREVIOUS_QUERIES),
                ],
                func=render_previous_step_queries,
            ),
        )

        extra_requirements_rendering_step = ToolExecutionStep(
            name=EXTRA_REQUIREMENTS_RENDERING_STEP,
            tool=ServerTool(
                name="render_extra_requirements",
                description="Rendering extra requirements to put in the prompt",
                input_descriptors=[
                    StringProperty(name=STEP_VALUE_EXTRACTION_IO),
                ],
                output_descriptors=[
                    StringProperty(name=EXTRA_REQUIREMENTS_IO),
                ],
                func=render_extra_requirements,
            ),
        )

        llm_query_generation_step = PromptExecutionStep(
            name=LLM_QUERY_GENERATION_STEP,
            prompt_template=INFORMER_PROMPT,
            llm=self.llm,
            input_descriptors=[
                StringProperty(name=TASK_EXTRACTION_IO),
                StringProperty(name=TABLES_IO),
            ],
            output_descriptors=[
                StringProperty(name=PromptExecutionStep.OUTPUT),
            ],
        )

        query_extraction_step = get_regex_extraction_step(
            name=QUERY_EXTRACTION_STEP,
            regex_pattern=r"```(?:sql)?\s*([\s\S]*?)```",
            return_first_match_only=True,
        )

        query_execution_step = ToolExecutionStep(
            name=QUERY_EXECUTION_STEP,
            tool=execute_query_tool(memories),
            input_descriptors=[
                StringProperty(name=QUERY_EXTRACTION_IO),
                DictProperty(name=DATA_TABLES),
            ],
            output_descriptors=[
                StringProperty(name=ToolExecutionStep.TOOL_OUTPUT),
            ],
            raise_exceptions=True,
        )

        query_context_update_step = ToolExecutionStep(
            name=QUERY_CONTEXT_UPDATE_STEP,
            tool=get_update_query_context_memory_tool(memories),
            input_descriptors=[
                StringProperty(name="rank"),
                StringProperty(name="content"),
                StringProperty(name="module", default_value="informer"),
            ],
            output_descriptors=[
                StringProperty(name=ToolExecutionStep.TOOL_OUTPUT),
            ],
        )

        informational_memory_update_step = ToolExecutionStep(
            name=INFORMATIONAL_MEMORY_UPDATE_STEP,
            tool=get_update_informational_memory_tool(memories),
            input_descriptors=[
                StringProperty(name="rank"),
                StringProperty(name="content"),
            ],
            output_descriptors=[
                StringProperty(name=ToolExecutionStep.TOOL_OUTPUT),
            ],
        )

        flow = Flow(
            begin_step=start_step,
            control_flow_edges=[
                ControlFlowEdge(source_step=start_step, destination_step=retrieve_context_step),
                ControlFlowEdge(
                    source_step=retrieve_context_step,
                    destination_step=previous_queries_rendering_step,
                ),
                ControlFlowEdge(
                    source_step=previous_queries_rendering_step,
                    destination_step=extra_requirements_rendering_step,
                ),
                ControlFlowEdge(
                    source_step=extra_requirements_rendering_step,
                    destination_step=llm_query_generation_step,
                ),
                ControlFlowEdge(
                    source_step=llm_query_generation_step,
                    destination_step=query_extraction_step,
                ),
                ControlFlowEdge(
                    source_step=query_extraction_step, destination_step=query_execution_step
                ),
                ControlFlowEdge(
                    source_step=query_execution_step, destination_step=query_context_update_step
                ),
                ControlFlowEdge(
                    source_step=query_context_update_step,
                    destination_step=informational_memory_update_step,
                ),
                ControlFlowEdge(
                    source_step=informational_memory_update_step, destination_step=None
                ),
            ],
            data_flow_edges=[
                DataFlowEdge(
                    start_step,
                    STEP_VALUE_EXTRACTION_IO,
                    previous_queries_rendering_step,
                    STEP_VALUE_EXTRACTION_IO,
                ),
                DataFlowEdge(
                    start_step,
                    STEP_VALUE_EXTRACTION_IO,
                    extra_requirements_rendering_step,
                    STEP_VALUE_EXTRACTION_IO,
                ),
                DataFlowEdge(
                    previous_queries_rendering_step,
                    RENDERED_PREVIOUS_QUERIES,
                    llm_query_generation_step,
                    RENDERED_PREVIOUS_QUERIES,
                ),
                DataFlowEdge(
                    extra_requirements_rendering_step,
                    EXTRA_REQUIREMENTS_IO,
                    llm_query_generation_step,
                    EXTRA_REQUIREMENTS_IO,
                ),
                DataFlowEdge(
                    start_step, TASK_EXTRACTION_IO, llm_query_generation_step, TASK_EXTRACTION_IO
                ),
                DataFlowEdge(start_step, TABLES_IO, llm_query_generation_step, TABLES_IO),
                DataFlowEdge(
                    retrieve_context_step,
                    ToolExecutionStep.TOOL_OUTPUT,
                    previous_queries_rendering_step,
                    RETRIEVE_CONTEXT_IO,
                ),
                DataFlowEdge(
                    llm_query_generation_step,
                    PromptExecutionStep.OUTPUT,
                    query_extraction_step,
                    RegexExtractionStep.TEXT,
                ),
                DataFlowEdge(
                    query_extraction_step,
                    RegexExtractionStep.OUTPUT,
                    query_execution_step,
                    QUERY_EXTRACTION_IO,
                ),
                DataFlowEdge(
                    start_step,
                    DATA_TABLES,
                    query_execution_step,
                    DATA_TABLES,
                ),
                DataFlowEdge(
                    query_extraction_step,
                    RegexExtractionStep.OUTPUT,
                    query_context_update_step,
                    "content",
                ),
                DataFlowEdge(
                    start_step, STEP_VALUE_EXTRACTION_IO, query_context_update_step, "rank"
                ),
                DataFlowEdge(
                    query_execution_step,
                    ToolExecutionStep.TOOL_OUTPUT,
                    informational_memory_update_step,
                    "content",
                ),
                DataFlowEdge(
                    start_step, STEP_VALUE_EXTRACTION_IO, informational_memory_update_step, "rank"
                ),
            ],
        )
        return flow
