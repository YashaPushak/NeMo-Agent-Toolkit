# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.

import re
from textwrap import dedent
from typing import Any, cast

import pandas as pd
from sqlalchemy import create_engine

from redflagverification.helpers.openagentspec import (
    get_regex_extraction_step,
    get_template_rendering_step,
)
from redflagverification.stages.constants import (
    ANSWER_QUESTION,
    CLARIFICATION_ANSWER,
    CLARIFICATION_QUESTION,
    CLARIFICATION_QUESTIONS,
    CLARIFICATIONS_IO,
    CUSTOMER_ID_IO,
    FINAL_EXTRACTION_STEP,
    FINAL_REFORMULATION_STEP,
    IS_CLARIFICATION_NEEDED_BRANCHING_STEP,
    IS_CLARIFICATION_NEEDED_STEP,
    IS_UNDETERMINED,
    IS_UNDETERMINED_STEP,
    PERIOD_IO,
    Q_REGEX_OUTPUT,
    QUESTION_IO,
    QUESTIONING_STEP,
    QUESTIONS_EXTRACTION_STEP,
    REFORMULATED_QUESTION_EXTRACTION_STEP,
    REFORMULATED_QUESTION_IO,
    REFORMULATION_STEP,
    RENDERING_STEP,
    SCENARIO_NAME_IO,
    START_STEP,
    STATEMENT_IO,
    STATEMENT_IO_RAW,
    TABLES_IO,
    THRESHOLD_GET_STEP,
    THRESHOLD_TABLE_IO,
    THRESHOLD_TABLES,
    USER_ASKING_STEP,
)
from redflagverification.stages.query_reformulation_stage.question_flow import question_flow
from redflagverification.tracing.exporters import InMemoryExporter
from redflagverification.tracing.rfvtrace import RFVTrace, debug_enabled
from redflagverification.tracing.spans import QuestionReformulationSpan
from wayflowcore.controlconnection import ControlFlowEdge
from wayflowcore.dataconnection import DataFlowEdge
from wayflowcore.executors.executionstatus import ExecutionStatus
from wayflowcore.flow import Flow
from wayflowcore.flowconversation import FlowConversation
from wayflowcore.models.llmmodel import LlmModel
from wayflowcore.property import BooleanProperty, DictProperty, ListProperty, StringProperty
from wayflowcore.steps import (
    BranchingStep,
    MapStep,
    PromptExecutionStep,
    RegexExtractionStep,
    StartStep,
    TemplateRenderingStep,
    ToolExecutionStep,
)
from wayflowcore.tools import ServerTool
from wayflowcore.tracing.spanprocessor import SimpleSpanProcessor

REFORMULATION_PROMPT = """\
Assume we have a database composed of the following tables and metadata:
{{tables_io}}

You are also given a table containing relevant thresholds and definitions:
{{threshold_table_io}}

The following is a statement that may be vague, ambiguous, or subjective.
Your task: Reformulate the statement as a clear, specific, and measurable yes/no question that \
verifies whether the described event actually occurs in the database.
Use as much information as possible from the schema and thresholds table to clarify ambiguity.
IMPORTANT:
- All quantifications, thresholds, and explicit definitions for vague or subjective terms are \
ALWAYS included in the thresholds and definitions table; you must locate and use the precise value \
or definition for these in your reformulated question. Never leave such terms vague or \
unquantified, and never use (to clarify-n) for any threshold or definition that can be found in \
the thresholds table.
- The (to clarify-n) tag should be used ONLY for terms, actions, or references that CANNOT be \
defined or checked using the database schema and provided thresholds table, such as information \
about business/customer history or any details not available in the database.
- In your reformulated question, you cannot assume further access to the thresholds table or any \
variable names from it.
- Use the actual table and column names from the schema.
- If a condition, term, or aspect of the original statement cannot be checked, measured, or \
operationalized using ONLY the available schema and explicit threshold values (i.e., it requires \
human judgment, future action, or information outside the database), add a unique numbered '(to \
clarify-1)', '(to clarify-2)', etc., tag immediately after it in your question. Start at 1 and \
increment for each such term or condition.
- This includes any reference to actions or decisions outside the database (such as 'should', \
'requires review', etc.)—these must also be tagged for clarification.
- Present EVERY condition as a BULLET POINT, even if there is only one condition.
- Do NOT use any other formatting—EVERY condition must appear as a bullet point and numbered '(to \
clarify-n)' tags must be used for ambiguous, subjective, or non-operationalizable terms as above.
- Your reformulated question should be simple for an agent that will directly use it to access the \
database to answer.
- Explain in detail why you marked a condition as to-clarify: mention the candidate thresholds or \
options you considered, and explain why you could not decide on one.

Here is the original statement: {{statement_io}}

Your output should be in the below format:
Thoughts: <thoughts before reformulating the given statement>
Reformulated question: <A clear, specific, yes/no-style question that expresses EACH condition as \
a bullet point for easy identification. Use '(to clarify-1)', '(to clarify-2)', etc., after any \
uncheckable, subjective, or non-operationalizable condition or term, incrementing the number for \
each occurrence.>
"""

CLARIFICATION_PROMPT = """\
You are assisting with clarifying ambiguous or uncheckable conditions in a database investigation.

Here is the database schema and relevant metadata:
{{tables_io}}

Here is the original red flag statement:
{{statement_io}}

Here is a reformulated question based on the red flag statement, where any condition that could \
not be operationalized is marked with a unique numbered '(to clarify-1)', '(to clarify-2)', etc. tag:
{{reformulated_question_io}}

Your task:
- Briefly write your thoughts on whether the reformulated question contains any conditions marked \
with '(to clarify-X)', and if so, what they imply for further investigation.
- Read the reformulated question and identify every condition marked with a '(to clarify-X)' tag.
- For each such condition, generate a single clear and concise question that would help clarify or \
make that condition precise; the condition can be a piece of information that is not available in \
the database, use the partial information you have if you do in the question to make it more straight.
- Use details from the schema, the reformulated question, and the original red flag statement to \
make your clarification questions as specific as possible.
- Always output in the following format:
thoughts: <your brief thoughts here>
Questions :
1. <clarification question>
2. <clarification question>
...and so on, one question for each '(to clarify-X)' in the reformulated question.

If there are no '(to clarify-X)' tags present, write your thoughts and under 'Questions :' output \
'(NO QUESTION)'.
"""

CLARIFICATION_INTEGRATION_PROMPT = """\
You are assisting in refining ambiguous monitoring statements for database checking.

Here is:
- The original red flag statement.
- The reformulated question (in bullet points; any ambiguous/uncheckable condition is marked with \
a '(to clarify-X)' tag).
- For each '(to clarify-X)' tag, there is a clarification answer.

Your task:
- For every bullet point with a '(to clarify-X)' tag, use the corresponding clarification answer \
to rewrite that bullet with the now precise information. Remove the '(to clarify-X)' tag.
- For bullet points without a '(to clarify-X)' tag, leave them unchanged.
- Output the complete set of clarified bullet points.
- Do not mention the original tags or that clarifications were applied—just output improved bullet \
points.
- Use only bullet point formatting.

Red flag statement:
{{ statement_io }}

Reformulated question:
{{ reformulated_question_io }}

Clarification answers:
{{ clarifications }}

Output the clarified reformulated question in exactly the same format as the first reformulated \
question: start with the line "Reformulated question:" followed by the reformulated question.
"""


def concatenate_clarifications(clarifications_io: list[str]) -> str:
    return "\n".join(f"{i}. {clarification}" for i, clarification in enumerate(clarifications_io))


def execute_query_tool() -> ServerTool:
    def run_query(scenario_name_io: str, threshold_tables: dict[str, str]) -> str:
        if scenario_name_io == "":
            return ""
        sceanrio_names = scenario_name_io.split("; ")
        if len(sceanrio_names) == 1:
            scenario_conditions = f"s.SCNRO_NM like '%{scenario_name_io}%'"
        else:
            scenario_conditions = " OR ".join(
                [f"s.SCNRO_NM like '%{name}%'" for name in sceanrio_names]
            )
        scenario_conditions = f"({scenario_conditions})"

        engine = create_engine("sqlite:///:memory:")

        for table_name, table_content in threshold_tables.items():
            df = pd.read_csv(pd.io.common.StringIO(table_content))
            df.to_sql(table_name, engine, if_exists="replace", index=False)

        query = dedent(
            f"""
            select t.TSHLD_NM, t.CURR_VALUE_TX, t.VALUE_TYPE_CD, DESC_TX
            from SCNRO s
            join TSHLD t on t.SCNRO_ID = s.SCNRO_ID
            where t.BASE_TSHLD_FL = 'Y'
            and t.DEACT_TS is null
            and {scenario_conditions}
            and (s.SCNRO_NM like '%ML/CU%' OR s.SCNRO_NM like '%ML/AC%')
            and UPPER(TRIM(t.CURR_VALUE_TX)) <> '''INACTIVE'''
            order by s.SCNRO_ID;
            """
        )

        df = pd.read_sql(query, engine)

        threshold_lines = [
            f"{row['TSHLD_NM']} = {row['CURR_VALUE_TX']} ({row['DESC_TX']})"
            for _, row in df.iterrows()
        ]
        threshold_table = "\n".join(threshold_lines)
        return threshold_table

    return ServerTool(
        name="execute_query_tool",
        description="executes a query on mock FCDM Schema adn outputs in string format",
        parameters={
            SCENARIO_NAME_IO: {
                "description": "Query to be executed",
                "type": "string",
                "default": "",
            },
            THRESHOLD_TABLES: {
                "description": "Dict with threshold tables as values.",
                "type": "object",
                "default": "",
            },
        },
        func=run_query,
        output={"type": "string"},
    )


def questions_extraction_tool() -> ServerTool:
    def extract_q(
        prompt_output: str,
    ) -> list[str]:
        questions = prompt_output.split("Questions")[1]
        if "NO QUESTION" in questions:
            return []
        list_questions = questions.split("\n")[1:]
        return list_questions

    return ServerTool(
        name="extract_q",
        description="retrieve from memory info to answer the question",
        input_descriptors=[
            StringProperty(name="prompt_output", description="prompt output", default_value="")
        ],
        output_descriptors=[ListProperty(name="question_list", item_type=StringProperty())],
        func=extract_q,
    )


def is_undetermined_tool() -> ServerTool:
    def is_undetermined(
        clarification_question: list[str],
        clarification_answer: list[str],
        llm_clarification_answer: list[str],
    ) -> dict[str, bool | list[str]]:
        clarification_questions = [
            q for q, a in zip(clarification_question, clarification_answer) if a == "0"
        ]  # removed questions that answer came from RAG
        is_undetermined = len(clarification_questions) > 0  # flag for undetermined label
        pattern = re.compile(r"""\s*["']?0["']?.?$""")
        llm_not_answered = [a for a in llm_clarification_answer if a == "0" or pattern.search(a)]
        successful_reformulation = len(llm_not_answered) == 0

        return {
            "is_undetermined": is_undetermined,
            "clarification_questions": clarification_questions,
            "successful_reformulation": successful_reformulation,
        }

    return ServerTool(
        name="is_undetermined",
        description="Bundles clarifying question with RAG answer.",
        input_descriptors=[
            ListProperty(
                name="clarification_question",
                description="Clarifying Question for the Red flag.",
                default_value=[],
                item_type=StringProperty(),
            ),
            ListProperty(
                name="clarification_answer",
                description="RAG attempted answer, '0' means that answer wasn't provided by RAG.",
                default_value=[],
                item_type=StringProperty(),
            ),
            ListProperty(
                name="llm_clarification_answer",
                description="LLM attempted answer, '0' means that answer wasn't provided by LLM.",
                default_value=[],
                item_type=StringProperty(),
            ),
        ],
        func=is_undetermined,
        output_descriptors=[
            BooleanProperty(name=IS_UNDETERMINED),
            ListProperty(name=CLARIFICATION_QUESTIONS, item_type=StringProperty()),
            BooleanProperty(name="successful_reformulation"),
        ],
    )


def get_reformulation_flow(
    llm_master: LlmModel, llm_question: LlmModel, knowledge_base: list[dict[str, str]]
) -> Flow:

    start_step = StartStep(
        name=START_STEP,
        input_descriptors=[
            StringProperty(
                name=TABLES_IO, description="Schema description of the available tables."
            ),
            StringProperty(name=STATEMENT_IO_RAW, description="Task Definition"),
            StringProperty(name=SCENARIO_NAME_IO, description="Scenario of Red Flag"),
            StringProperty(name=PERIOD_IO, description="Scenario of Red Flag"),
            StringProperty(name=CUSTOMER_ID_IO, description="Scenario of Red Flag"),
            DictProperty(
                name=THRESHOLD_TABLES, description="Threshold tables for different scenarios."
            ),
        ],
    )

    rendering_step = get_template_rendering_step(
        name=RENDERING_STEP,
        template="{{ statement_io_raw }} for customer with customer ID = {{ customer_id_io }} for the period: {{ period_io }}",
    )

    threshold_get_step = ToolExecutionStep(
        name=THRESHOLD_GET_STEP,
        tool=execute_query_tool(),
        input_descriptors=[
            StringProperty(name=SCENARIO_NAME_IO),
            DictProperty(name=THRESHOLD_TABLES),
        ],
        output_descriptors=[
            StringProperty(name=ToolExecutionStep.TOOL_OUTPUT),
        ],
    )

    reformulation_step = PromptExecutionStep(
        name=REFORMULATION_STEP,
        prompt_template=REFORMULATION_PROMPT,
        llm=llm_master,
        input_descriptors=[
            StringProperty(name=TABLES_IO),
            StringProperty(name=STATEMENT_IO),
            StringProperty(name=THRESHOLD_TABLE_IO),
        ],
        output_descriptors=[
            StringProperty(name=PromptExecutionStep.OUTPUT),
        ],
    )

    reformulated_question_extraction_step = get_regex_extraction_step(
        name=REFORMULATED_QUESTION_EXTRACTION_STEP,
        regex_pattern=r"Reformulated question:\s*((?:.|\n)*)",
    )

    is_clarification_needed_step = ToolExecutionStep(
        name=IS_CLARIFICATION_NEEDED_STEP,
        tool=ServerTool(
            name="find_clarify_tag",
            description="Check whether clarification is needed by looking for (to clarify-X) tags",
            input_descriptors=[StringProperty(name="input_text")],
            output_descriptors=[StringProperty(name="exist_clarify_tag")],
            func=lambda input_text: (
                "need_clarification"
                if re.findall(r"\(to clarify-", input_text)
                else "no_clarification"
            ),
        ),
    )

    is_clarification_needed_branching_step = BranchingStep(
        name=IS_CLARIFICATION_NEEDED_BRANCHING_STEP,
        branch_name_mapping={
            "no_clarification": "no_clarification",
        },
    )

    questioning_step = PromptExecutionStep(
        name=QUESTIONING_STEP,
        prompt_template=CLARIFICATION_PROMPT,
        llm=llm_question,
        input_descriptors=[
            StringProperty(name=REFORMULATED_QUESTION_IO),
            StringProperty(name=STATEMENT_IO),
            StringProperty(name=TABLES_IO),
        ],
        output_descriptors=[
            StringProperty(name=PromptExecutionStep.OUTPUT),
        ],
    )

    questions_extraction_step = ToolExecutionStep(
        name=QUESTIONS_EXTRACTION_STEP,
        tool=questions_extraction_tool(),
        input_descriptors=[
            StringProperty(name="prompt_output"),
        ],
        output_descriptors=[
            ListProperty(name="question_list"),
        ],
    )

    user_asking_step = MapStep(
        name=USER_ASKING_STEP,
        flow=question_flow(llm=llm_question, knowledge_base=knowledge_base),
        unpack_input={QUESTION_IO: "."},
        input_descriptors=[
            StringProperty(name=TABLES_IO, description="Tables Schema"),
            StringProperty(name=STATEMENT_IO, description="Red Flag"),
            ListProperty(name=MapStep.ITERATED_INPUT, description="iterated_input"),
        ],
        output_descriptors=[
            ListProperty(name="clarification"),
            ListProperty(name=Q_REGEX_OUTPUT),
            ListProperty(name=ANSWER_QUESTION),
        ],
    )

    concatenate_clarifications_step = ToolExecutionStep(
        name="concatenate_clarifications_step",
        tool=ServerTool(
            name="concatenate_clarifications",
            description="Concatenate clarifications",
            func=concatenate_clarifications,
            input_descriptors=[StringProperty(name=CLARIFICATIONS_IO)],
            output_descriptors=[StringProperty(name="clarifications")],
        ),
    )

    final_reformulation_step = PromptExecutionStep(
        name=FINAL_REFORMULATION_STEP,
        prompt_template=CLARIFICATION_INTEGRATION_PROMPT,
        llm=llm_master,
        input_descriptors=[
            StringProperty(name=REFORMULATED_QUESTION_IO),
            StringProperty(name=STATEMENT_IO),
            StringProperty(name="clarifications"),
        ],
        output_descriptors=[
            StringProperty(name=PromptExecutionStep.OUTPUT),
        ],
    )

    final_extraction_step = get_regex_extraction_step(
        name=FINAL_EXTRACTION_STEP,
        regex_pattern=r"Reformulated question:\s*((?:.|\n)*)",
    )

    is_undetermined_step = ToolExecutionStep(name=IS_UNDETERMINED_STEP, tool=is_undetermined_tool())

    flow = Flow(
        begin_step=start_step,
        control_flow_edges=[
            ControlFlowEdge(start_step, rendering_step),
            ControlFlowEdge(rendering_step, threshold_get_step),
            ControlFlowEdge(threshold_get_step, reformulation_step),
            ControlFlowEdge(reformulation_step, reformulated_question_extraction_step),
            ControlFlowEdge(reformulated_question_extraction_step, is_clarification_needed_step),
            ControlFlowEdge(is_clarification_needed_step, is_clarification_needed_branching_step),
            ControlFlowEdge(
                is_clarification_needed_branching_step,
                questioning_step,
                source_branch=BranchingStep.BRANCH_DEFAULT,
            ),
            ControlFlowEdge(
                is_clarification_needed_branching_step,
                is_undetermined_step,
                source_branch="no_clarification",
            ),
            ControlFlowEdge(questioning_step, questions_extraction_step),
            ControlFlowEdge(questions_extraction_step, user_asking_step),
            ControlFlowEdge(user_asking_step, concatenate_clarifications_step),
            ControlFlowEdge(concatenate_clarifications_step, final_reformulation_step),
            ControlFlowEdge(final_reformulation_step, final_extraction_step),
            ControlFlowEdge(final_extraction_step, is_undetermined_step),
            ControlFlowEdge(is_undetermined_step, None),
        ],
        data_flow_edges=[
            DataFlowEdge(start_step, CUSTOMER_ID_IO, rendering_step, CUSTOMER_ID_IO),
            DataFlowEdge(start_step, PERIOD_IO, rendering_step, PERIOD_IO),
            DataFlowEdge(start_step, STATEMENT_IO_RAW, rendering_step, STATEMENT_IO_RAW),
            DataFlowEdge(start_step, SCENARIO_NAME_IO, threshold_get_step, SCENARIO_NAME_IO),
            DataFlowEdge(start_step, THRESHOLD_TABLES, threshold_get_step, THRESHOLD_TABLES),
            DataFlowEdge(start_step, TABLES_IO, reformulation_step, TABLES_IO),
            DataFlowEdge(
                rendering_step, TemplateRenderingStep.OUTPUT, reformulation_step, STATEMENT_IO
            ),
            DataFlowEdge(
                threshold_get_step,
                ToolExecutionStep.TOOL_OUTPUT,
                reformulation_step,
                THRESHOLD_TABLE_IO,
            ),
            DataFlowEdge(
                reformulation_step,
                PromptExecutionStep.OUTPUT,
                reformulated_question_extraction_step,
                RegexExtractionStep.TEXT,
            ),
            DataFlowEdge(
                start_step,
                TABLES_IO,
                questioning_step,
                TABLES_IO,
            ),
            DataFlowEdge(
                rendering_step,
                TemplateRenderingStep.OUTPUT,
                questioning_step,
                STATEMENT_IO,
            ),
            DataFlowEdge(
                reformulated_question_extraction_step,
                RegexExtractionStep.OUTPUT,
                is_clarification_needed_step,
                "input_text",
            ),
            DataFlowEdge(
                is_clarification_needed_step,
                "exist_clarify_tag",
                is_clarification_needed_branching_step,
                BranchingStep.NEXT_BRANCH_NAME,
            ),
            DataFlowEdge(
                reformulated_question_extraction_step,
                RegexExtractionStep.OUTPUT,
                questioning_step,
                REFORMULATED_QUESTION_IO,
            ),
            DataFlowEdge(
                questioning_step,
                PromptExecutionStep.OUTPUT,
                questions_extraction_step,
                "prompt_output",
            ),
            DataFlowEdge(
                questions_extraction_step,
                "question_list",
                user_asking_step,
                MapStep.ITERATED_INPUT,
            ),
            DataFlowEdge(
                start_step,
                TABLES_IO,
                user_asking_step,
                TABLES_IO,
            ),
            DataFlowEdge(
                rendering_step,
                TemplateRenderingStep.OUTPUT,
                user_asking_step,
                STATEMENT_IO,
            ),
            DataFlowEdge(
                user_asking_step,
                "clarification",
                concatenate_clarifications_step,
                CLARIFICATIONS_IO,
            ),
            DataFlowEdge(
                concatenate_clarifications_step,
                "clarifications",
                final_reformulation_step,
                "clarifications",
            ),
            DataFlowEdge(
                reformulated_question_extraction_step,
                RegexExtractionStep.OUTPUT,
                final_reformulation_step,
                REFORMULATED_QUESTION_IO,
            ),
            DataFlowEdge(
                rendering_step,
                TemplateRenderingStep.OUTPUT,
                final_reformulation_step,
                STATEMENT_IO,
            ),
            DataFlowEdge(
                final_reformulation_step,
                PromptExecutionStep.OUTPUT,
                final_extraction_step,
                RegexExtractionStep.TEXT,
            ),
            DataFlowEdge(
                questions_extraction_step,
                "question_list",
                is_undetermined_step,
                CLARIFICATION_QUESTION,
            ),
            DataFlowEdge(
                user_asking_step,
                Q_REGEX_OUTPUT,
                is_undetermined_step,
                CLARIFICATION_ANSWER,
            ),
            DataFlowEdge(
                user_asking_step,
                ANSWER_QUESTION,
                is_undetermined_step,
                "llm_clarification_answer",
            ),
        ],
    )
    return flow


async def _run_reformulation_with_span(
    flow: Flow,
    tables: str,
    statement: str,
    scenario: str,
    customer_id: str,
    period: str,
    threshold_tables: dict[str, str],
    span_exporter: InMemoryExporter,
) -> tuple[dict[str, Any], ExecutionStatus, FlowConversation]:
    """
    Execute the reformulation flow inside a QuestionReformulationSpan and emit tracing to
    span_exporter.

    Returns:
        tuple[dict[str, Any], ExecutionStatus, FlowConversation]
        where the dict is the slim reformulation trace.
    """
    with QuestionReformulationSpan(
        red_flag=statement,
        customer_id=customer_id,
        investigation_period=period,
        scenario=scenario,
    ) as span:
        conversation = flow.start_conversation(
            inputs={
                TABLES_IO: tables,
                STATEMENT_IO_RAW: statement,
                SCENARIO_NAME_IO: scenario,
                CUSTOMER_ID_IO: customer_id,
                PERIOD_IO: period,
                THRESHOLD_TABLES: threshold_tables,
            }
        )
        status = await conversation.execute_async()
        span.record_end_span_event(span_exporter.span_list)
        result = span._get_slim_trace()
    return result, status, conversation


async def run_question_reformulation(
    tables: str,
    statement: str,
    scenario: str,
    customer_id: str,
    period: str,
    llm_master: LlmModel,
    llm_question: LlmModel,
    threshold_tables: dict[str, str],
    knowledge_base: list[dict[str, Any]],
    span_exporter: InMemoryExporter | None = None,
) -> dict[str, Any]:
    """
    Initiate and manage a question reformulation workflow using language models within a guided
    conversation. If clarification questions arise, the conversation flow is continued automatically
    using LLM-generated placeholder answers. Returns the reformulation trace.

    If one or more clarification questions are auto-answered by the LLM, 'is_undetermined' is set to
    True, and 'clarification_questions' will contain the corresponding questions. This allows the
    questions to be logged and, if needed, reviewed or answered by a human later. When
    'is_undetermined' is True, the reformulated output should not be used as final, since it may be
    incomplete or require further verification.

    Behavior:
    - Builds the reformulation flow (rendering + thresholds retrieval + reformulation + optional
    clarifications).
    - If span_exporter is provided, uses the caller-managed Trace/exporter; otherwise creates a
    local Trace.
    - Executes within a QuestionReformulationSpan and exports span events.

    Args:
        tables (str): Information about database tables.
        statement (str): The raw red flag statement to be reformulated.
        scenario (str): Scenario name, used to retrieve red flag thresholds.
        customer_id (str): Identifier for the relevant customer context.
        period (str): Specified time period for the context.
        llm_master (LlmModel): The primary language model used for the query reformualtion.
        llm_question (LlmModel): Language model used for clarifying questions/answers.
        threshold_tables (dict[str, str]): Dict with keys being table names and value an str
            representation of the table contents.
        knowledge_base (list[dict[str, Any]]): Knowledge base containg memory questions and
            plans/answers. Used for RAG.
        span_exporter (InMemoryExporter | None): exporter to collect span events.
            - If None, a local InMemoryExporter is created and managed internally.
            - If provided, no new Trace is created; the caller is responsible for the outer Trace
                context.

    Returns:
        dict[str, Any]: reformulation trace that includes:
        - red_flag, customer_id, investigation_period, scenario
        - retrieved_threshold_rows
        - initial_reformulation
        - clarification_question_answer (list of dicts: question, search_result, answer, undetermined)
        - final_reformulation
        - llm_call_stats (per-call stats) and total_stats (by model_id)
    """
    flow = get_reformulation_flow(llm_master, llm_question, knowledge_base)

    if span_exporter is None:
        local_exporter = InMemoryExporter()
        with RFVTrace(debug=debug_enabled(), span_processors=[SimpleSpanProcessor(local_exporter)]):
            result, status, conversation = await _run_reformulation_with_span(
                flow=flow,
                tables=tables,
                statement=statement,
                scenario=scenario,
                customer_id=customer_id,
                period=period,
                threshold_tables=threshold_tables,
                span_exporter=local_exporter,
            )
    else:
        result, status, conversation = await _run_reformulation_with_span(
            flow=flow,
            tables=tables,
            statement=statement,
            scenario=scenario,
            customer_id=customer_id,
            period=period,
            threshold_tables=threshold_tables,
            span_exporter=span_exporter,
        )

    return result


def parse_reformulation_trace(trace: dict[str, Any]) -> tuple[str, bool, list[str], bool]:
    question = trace.get("final_reformulation")
    if not isinstance(question, str) or not question:
        raise TypeError("Question reformulation failed")

    clar_entries = trace.get("clarification_question_answer") or []
    clarification_questions = [entry.get("question") for entry in clar_entries]
    is_undetermined = any(bool(e.get("undetermined")) for e in clar_entries)
    successful_reformulation = cast(bool, trace.get("successful_reformulation"))
    return question, is_undetermined, clarification_questions, successful_reformulation
