# Copyright (C) 2025 Oracle and/or its affiliates. All rights reserved.
from textwrap import dedent

from redflagverification.helpers.llm_helper import get_llm
from redflagverification.helpers.openagentspec import get_regex_extraction_step
from redflagverification.memory.configuration import EmbeddingPolicy
from redflagverification.memory.memory import DB_STORAGE_PROMPT, TextChunkMemory
from redflagverification.stages.constants import (
    ANSWER_QUESTION,
    ANSWERING_TRIAL_STEP,
    AUTO_INPUT_STEP,
    BRANCHING_STEP,
    DECISION_EXTRACTION_STEP,
    OUTPUT_MESSAGE,
    Q_REGEX_OUTPUT,
    QUESTION_IO,
    RAG_RESULT_IO,
    RETRIEVAL_EXECUTION_STEP,
    START_STEP,
    STATEMENT_IO,
    TABLES_IO,
)
from wayflowcore.controlconnection import ControlFlowEdge
from wayflowcore.dataconnection import DataFlowEdge
from wayflowcore.datastore import Entity, InMemoryDatastore
from wayflowcore.flow import Flow
from wayflowcore.models.llmmodel import LlmModel
from wayflowcore.property import ListProperty, ObjectProperty, StringProperty
from wayflowcore.steps import (
    BranchingStep,
    OutputMessageStep,
    PromptExecutionStep,
    RegexExtractionStep,
    StartStep,
    ToolExecutionStep,
)
from wayflowcore.tools import ServerTool


def create_clarification(question_io: str, answer_question: str) -> str:
    return f"The answer for question : {question_io} is {answer_question}"


def concatenate_rag_results(rag_result_io: list[str]) -> str:
    return "\n".join(rag_result_io)


def retrieval_tool(knowledge_base: list[dict[str, str]]) -> ServerTool:
    # initialization of the datastore and memory needs to be moved to be done in a broader scope
    # when we want to add entries to memory in the future since we need the object references
    memory_schema = Entity(
        properties={
            "original_statement": StringProperty(),
            "user_question": StringProperty(),
            "answer": StringProperty(),
            "metadata": ObjectProperty(
                properties={
                    "plan": ListProperty(item_type=StringProperty()),
                    "embedding_hints": ListProperty(item_type=StringProperty()),
                    "scope": StringProperty(),
                    "strategy": StringProperty(),
                    "note": StringProperty(),
                    "categories": ListProperty(item_type=StringProperty()),
                }
            ),
        }
    )

    datastore = InMemoryDatastore({"fcc": memory_schema})

    datastore.create("fcc", knowledge_base)

    embedding_policy = EmbeddingPolicy(
        embedding_template="{{ doc.user_question }}\n{{ doc.metadata.embedding_hints|join(' ') }}",
        retrieval_template="{{ doc.user_question }}\nPlan: {{ doc.metadata.plan }}",
    )

    memory = TextChunkMemory(
        llm=get_llm(),
        data_store=datastore,
        scope_id="fcc",
        extraction_instruction=DB_STORAGE_PROMPT,
        embedding_policy=embedding_policy,
    )

    return memory.get_search_tool()


def question_flow(llm: LlmModel, knowledge_base: list[dict[str, str]]) -> Flow:

    start_step = StartStep(
        name=START_STEP,
        input_descriptors=[
            StringProperty(name=QUESTION_IO),
            StringProperty(name=STATEMENT_IO),
            StringProperty(name=TABLES_IO),
        ],
    )

    retrieval_execution_step = ToolExecutionStep(
        name=RETRIEVAL_EXECUTION_STEP,
        tool=retrieval_tool(knowledge_base),
    )

    format_rag_result_step = ToolExecutionStep(
        name="format_rag_result_step",
        tool=ServerTool(
            name="concatenate_rag_results",
            description="Concatenate rag results",
            input_descriptors=[ListProperty(name=RAG_RESULT_IO, item_type=StringProperty())],
            output_descriptors=[StringProperty(name="rag_result")],
            func=concatenate_rag_results,
        ),
    )

    llm_prompt = (
        "=== RETRIEVED PLANS ===\n"
        "{{ rag_result }}\n"
        "=== END OF RETRIEVED PLANS ===\n\n"
        "Question: {{ question_io }}\n"
        "Red flag: {{ statement_io }}\n\n"
        "Based only on the above retrieved plans, answer the question as it relates to the red flag.\n"
        "Use only information present in the plans, focusing on relevant sequences of tasks.\n"
        "If the answer cannot be found within these plans, **reply with only '0'**.\n"
        "Answer:"
    )

    answering_trial_step = PromptExecutionStep(
        name=ANSWERING_TRIAL_STEP,
        prompt_template=llm_prompt,
        llm=llm,
        input_descriptors=[
            StringProperty(name="rag_result"),
            StringProperty(name=STATEMENT_IO),
            StringProperty(name=QUESTION_IO),
        ],
        output_descriptors=[StringProperty(name=ANSWER_QUESTION)],
    )

    decision_extraction_step = get_regex_extraction_step(
        name=DECISION_EXTRACTION_STEP,
        regex_pattern=r"^[\s\S]*$",
        output_name=Q_REGEX_OUTPUT,
    )

    branching_step = BranchingStep(
        name=BRANCHING_STEP,
        branch_name_mapping={
            "0": "ask_user",
        },
        input_descriptors=[
            StringProperty(name=BranchingStep.NEXT_BRANCH_NAME),
        ],
    )

    auto_input_prompt = dedent(
        """
        For the financial red flag {{ statement_io }}
        Draft a short, plausible response to the clarifying question:

        {{ question_io }}.

        If answering the question requires specifying where to find information in a table, your \
answer must comply with this schema:

        {{ tables_io }}

        Responses must be realistic, with exact values (e.g., “3 days” instead of \
“timeframe_window”), leaving no room for clarification. You should only answer with a direct \
response to the question without additional explanations. Do not generate any SQL query examples.
        The answer you give must be actionable given the above schema. If it cannot be \
operationalized because it would require information that is not present anywhere in the schema, \
**reply with only '0'**.
        Answer:
        """
    )
    auto_input_step = PromptExecutionStep(
        name=AUTO_INPUT_STEP,
        prompt_template=auto_input_prompt,
        llm=llm,
        output_descriptors=[StringProperty(name=ANSWER_QUESTION)],
    )

    create_clarification_step = ToolExecutionStep(
        name="create_clarification_step",
        tool=ServerTool(
            name="create_clarification",
            description="Create clarification",
            input_descriptors=[
                StringProperty(name=QUESTION_IO),
                StringProperty(name=ANSWER_QUESTION),
            ],
            output_descriptors=[StringProperty(name="clarification")],
            func=create_clarification,
        ),
    )

    output_message = OutputMessageStep(
        name=OUTPUT_MESSAGE,
        message_template="{{ clarification }}",
        expose_message_as_output=False,
    )

    flow = Flow(
        begin_step=start_step,
        control_flow_edges=[
            ControlFlowEdge(start_step, retrieval_execution_step),
            ControlFlowEdge(retrieval_execution_step, format_rag_result_step),
            ControlFlowEdge(format_rag_result_step, answering_trial_step),
            ControlFlowEdge(answering_trial_step, decision_extraction_step),
            ControlFlowEdge(decision_extraction_step, branching_step),
            ControlFlowEdge(
                source_step=branching_step,
                destination_step=auto_input_step,
                source_branch="ask_user",
            ),
            ControlFlowEdge(auto_input_step, create_clarification_step),
            ControlFlowEdge(create_clarification_step, output_message),
            ControlFlowEdge(
                source_step=branching_step,
                destination_step=create_clarification_step,
                source_branch=BranchingStep.BRANCH_DEFAULT,
            ),
            ControlFlowEdge(output_message, None),
        ],
        data_flow_edges=[
            DataFlowEdge(start_step, QUESTION_IO, retrieval_execution_step, "user_question"),
            DataFlowEdge(
                retrieval_execution_step,
                "search_result",
                format_rag_result_step,
                RAG_RESULT_IO,
            ),
            DataFlowEdge(format_rag_result_step, "rag_result", answering_trial_step, "rag_result"),
            DataFlowEdge(start_step, QUESTION_IO, answering_trial_step, QUESTION_IO),
            DataFlowEdge(start_step, STATEMENT_IO, answering_trial_step, STATEMENT_IO),
            DataFlowEdge(
                answering_trial_step,
                ANSWER_QUESTION,
                decision_extraction_step,
                RegexExtractionStep.TEXT,
            ),
            DataFlowEdge(
                decision_extraction_step,
                Q_REGEX_OUTPUT,
                create_clarification_step,
                ANSWER_QUESTION,
            ),
            DataFlowEdge(
                decision_extraction_step,
                Q_REGEX_OUTPUT,
                branching_step,
                BranchingStep.NEXT_BRANCH_NAME,
            ),
            DataFlowEdge(start_step, QUESTION_IO, create_clarification_step, QUESTION_IO),
            DataFlowEdge(
                auto_input_step,
                ANSWER_QUESTION,
                create_clarification_step,
                ANSWER_QUESTION,
            ),
            DataFlowEdge(
                create_clarification_step, "clarification", output_message, "clarification"
            ),
        ],
    )
    return flow
